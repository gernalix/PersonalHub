/*
 * This file is auto-generated.  DO NOT MODIFY.
 */
package net.osmand.aidlapi;
// NOTE: Add new methods at the end of file!!!
public interface IOsmAndAidlInterface extends android.os.IInterface
{
  /** Default implementation for IOsmAndAidlInterface. */
  public static class Default implements net.osmand.aidlapi.IOsmAndAidlInterface
  {
    /**
     * Add map marker at given location.
     * 
     * @param lat (double) -  latitude.
     * @param lon (double) - longitude.
     * @param name (String)- name of marker.
     */
    @Override public boolean addMapMarker(net.osmand.aidlapi.mapmarker.AddMapMarkerParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Remove map marker.
     * 
     * If ignoreCoordinates is false the marker is only removed if lat/lon match the currently set values of the marker.
     * If ignoreCoordinates is true the marker is removed if the name matches, the values of lat/lon are ignored.
     * 
     * @param lat (double) -  latitude.
     * @param lon (double) - longitude.
     * @param name (String)- name of marker.
     * @param ignoreCoordinates (boolean) - flag to determine whether lat/lon shall be ignored
     */
    @Override public boolean removeMapMarker(net.osmand.aidlapi.mapmarker.RemoveMapMarkerParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Update map marker.
     * 
     * If ignoreCoordinates is false the marker gets updated only if latPrev/lonPrev match the currently set values of the marker.
     * If ignoreCoordinates is true the marker gets updated if the name matches, the values of latPrev/lonPrev are ignored.
     * 
     * @param latPrev (double) - latitude (current marker).
     * @param lonPrev (double) - longitude (current marker).
     * @param namePrev (String) - name (current marker).
     * @param latNew (double) - latitude (new marker).
     * @param lonNew (double) - longitude (new marker).
     * @param nameNew (String) - name (new marker).
     * @param ignoreCoordinates (boolean) - flag to determine whether latPrev/lonPrev shall be ignored
     */
    @Override public boolean updateMapMarker(net.osmand.aidlapi.mapmarker.UpdateMapMarkerParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Add map widget to the right side of the main screen.
     * Note: any specified icon should exist in OsmAnd app resources.
     * 
     * @param id (String) - widget id.
     * @param menuIconName (String) - icon name (configure map menu).
     * @param menuTitle (String) - widget name (configure map menu).
     * @param lightIconName (String) - icon name for the light theme (widget).
     * @param darkIconName (String) - icon name for the dark theme (widget).
     * @param text (String) - main widget text.
     * @param description (String) - sub text, like "km/h".
     * @param order (int) - order position in the widgets list.
     * @param intentOnClick (String) - onClick intent. Called after click on widget as startActivity(Intent intent).
     */
    @Override public boolean addMapWidget(net.osmand.aidlapi.mapwidget.AddMapWidgetParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Remove map widget.
     * 
     * @param (String) id - widget id.
     */
    @Override public boolean removeMapWidget(net.osmand.aidlapi.mapwidget.RemoveMapWidgetParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Update map widget.
     * Note: any specified icon should exist in OsmAnd app resources.
     * 
     * @param id (String) - widget id.
     * @param menuIconName (String) - icon name (configure map menu).
     * @param menuTitle (String) - widget name (configure map menu).
     * @param lightIconName (String) - icon name for the light theme (widget).
     * @param darkIconName (String) - icon name for the dark theme (widget).
     * @param text (String) - main widget text.
     * @param description (String) - sub text, like "km/h".
     * @param order (int) - order position in the widgets list.
     * @param intentOnClick (String) - onClick intent. Called after click on widget as startActivity(Intent intent).
     */
    @Override public boolean updateMapWidget(net.osmand.aidlapi.mapwidget.UpdateMapWidgetParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Add point to user layer.
     * 
     * @param layerId (String) - layer id. Note: layer should be added first.
     * @param pointId (String) - point id.
     * @param shortName (String) - short name (single char). Displayed on the map.
     * @param fullName (String) - full name. Displayed in the context menu on first row.
     * @param typeName (String) - type name. Displayed in context menu on second row.
     * @param color (int) - color of circle's background.
     * @param location (ALatLon) - location of the point.
     * @param details (List<String>)- list of details. Displayed under context menu.
     * @param params (Map<String, String>) - optional map of params for point.
     */
    @Override public boolean addMapPoint(net.osmand.aidlapi.maplayer.point.AddMapPointParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Remove point.
     * 
     * @param layerId (String) - layer id.
     * @param pointId (String) - point id.
     */
    @Override public boolean removeMapPoint(net.osmand.aidlapi.maplayer.point.RemoveMapPointParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Update point.
     * 
     * @param layerId (String) - layer id.
     * @param pointId (String) - point id.
     * @param updateOpenedMenuAndMap (boolean) - flag to enable folowing mode and menu updates for point
     * @param shortName (String) - short name (single char). Displayed on the map.
     * @param fullName (String) - full name. Displayed in the context menu on first row.
     * @param typeName (String) - type name. Displayed in context menu on second row.
     * @param color (String) - color of circle's background.
     * @param location (ALatLon)- location of the point.
     * @param details (List<String>) - list of details. Displayed under context menu.
     * @param params (Map<String, String>) - optional map of params for point.
     */
    @Override public boolean updateMapPoint(net.osmand.aidlapi.maplayer.point.UpdateMapPointParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Add user layer on the map.
     * 
     * @param id (String) - layer id.
     * @param name (String) - layer name.
     * @param zOrder (float) - z-order position of layer. Default value is 5.5f
     * @param points Map<Sting, AMapPoint> - initial list of points. Nullable.
     * @param imagePoints (boolean) - use new style for points on map or not. Also default zoom bounds for new style can be edited.
     */
    @Override public boolean addMapLayer(net.osmand.aidlapi.maplayer.AddMapLayerParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Remove user layer.
     * 
     * @param id (String) - layer id.
     */
    @Override public boolean removeMapLayer(net.osmand.aidlapi.maplayer.RemoveMapLayerParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Update user layer.
     * 
     * @param id (String) - layer id.
     * @param name (String) - layer name.
     * @param zOrder (float) - z-order position of layer. Default value is 5.5f
     * @param points Map<Sting, AMapPoint> - list of points. Nullable.
     * @param imagePoints (boolean) - use new style for points on map or not. Also default zoom bounds for new style can be edited.
     */
    @Override public boolean updateMapLayer(net.osmand.aidlapi.maplayer.UpdateMapLayerParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Import GPX file to OsmAnd (from URI or file).
     * 
     * @param gpxUri (Uri) - URI created by FileProvider (preferable method).
     * @param file (File) - File which represents GPX track (not recomended, OsmAnd should have rights to access file location).
     * @param fileName (String) - Destination file name. May contain dirs.
     * @param color (String) - color of gpx. Can be one of: "red", "orange", "lightblue", "blue", "purple",
     *                    "translucent_red", "translucent_orange", "translucent_lightblue",
     *                    "translucent_blue", "translucent_purple"
     * @param show (boolean) - show track on the map after import
     */
    @Override public boolean importGpx(net.osmand.aidlapi.gpx.ImportGpxParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Show GPX file on map.
     * 
     * @param fileName (String) - file name to show. Must be imported first.
     */
    @Override public boolean showGpx(net.osmand.aidlapi.gpx.ShowGpxParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Hide GPX file.
     * 
     * @param fileName (String) - file name to hide.
     */
    @Override public boolean hideGpx(net.osmand.aidlapi.gpx.HideGpxParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Get list of active GPX files.
     * 
     * @return list of active gpx files.
     */
    @Override public boolean getActiveGpx(java.util.List<net.osmand.aidlapi.gpx.ASelectedGpxFile> files) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Set map view to current location.
     * 
     * @param latitude (double) - latitude of new map center.
     * @param longitude (double) - longitude of new map center.
     * @param zoom (float) - map zoom level. Set 0 to keep zoom unchanged.
     * @param animated (boolean) - set true to animate changes.
     */
    @Override public boolean setMapLocation(net.osmand.aidlapi.map.SetMapLocationParams params) throws android.os.RemoteException
    {
      return false;
    }
    @Override public boolean calculateRoute(net.osmand.aidlapi.calculateroute.CalculateRouteParams params) throws android.os.RemoteException
    {
      return false;
    }
    /** Refresh the map (UI) */
    @Override public boolean refreshMap() throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Add favorite group with given params.
     * 
     * @param name (String)    - group name.
     * @param color (String)  - group color. Can be one of: "red", "orange", "yellow",
     *                "lightgreen", "green", "lightblue", "blue", "purple", "pink", "brown".
     * @param visible (boolean) - group visibility.
     */
    @Override public boolean addFavoriteGroup(net.osmand.aidlapi.favorite.group.AddFavoriteGroupParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Remove favorite group with given name.
     * 
     * @param name (String) - name of favorite group.
     */
    @Override public boolean removeFavoriteGroup(net.osmand.aidlapi.favorite.group.RemoveFavoriteGroupParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Update favorite group with given params.
     * 
     * @param namePrev (String) - group name (current).
     * @param colorPrev (String) - group color (current).
     * @param visiblePrev (boolean) - group visibility (current).
     * @param nameNew (String)  - group name (new).
     * @param colorNew (String)  - group color (new).
     * @param visibleNew (boolean) - group visibility (new).
     */
    @Override public boolean updateFavoriteGroup(net.osmand.aidlapi.favorite.group.UpdateFavoriteGroupParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Add favorite at given location with given params.
     * 
     * @param lat (double) - latitude.
     * @param lon (double)  - longitude.
     * @param name (String)  - name of favorite item.
     * @param description (String)  - description of favorite item.
     * @param category (String)  - category of favorite item.
     * @param color (String)  - color of favorite item. Can be one of: "red", "orange", "yellow",
     *                    "lightgreen", "green", "lightblue", "blue", "purple", "pink", "brown".
     * @param visible (boolean) - should favorite item be visible after creation.
     */
    @Override public boolean addFavorite(net.osmand.aidlapi.favorite.AddFavoriteParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Remove favorite at given location with given params.
     * 
     * @param lat (double)  - latitude.
     * @param lon (double) - longitude.
     * @param name (String) - name of favorite item.
     * @param category (String) - category of favorite item.
     */
    @Override public boolean removeFavorite(net.osmand.aidlapi.favorite.RemoveFavoriteParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Update favorite at given location with given params.
     * 
     * @param latPrev (double)  - latitude (current favorite).
     * @param lonPrev (double) - longitude (current favorite).
     * @param namePrev (String) - name of favorite item (current favorite).
     * @param categoryPrev (String) - category of favorite item (current favorite).
     * @param latNew (double)  - latitude (new favorite).
     * @param lonNew (double)  - longitude (new favorite).
     * @param nameNew (String)  - name of favorite item (new favorite).
     * @param descriptionNew (String) - description of favorite item (new favorite).
     * @param categoryNew (String) - category of favorite item (new favorite). Use only to create a new category,
     *                       not to update an existing one. If you want to  update an existing category,
     *                       use the {@link #updateFavoriteGroup(String, String, boolean, String, String, boolean)} method.
     * @param colorNew (String) - color of new category. Can be one of: "red", "orange", "yellow",
     *                       "lightgreen", "green", "lightblue", "blue", "purple", "pink", "brown".
     * @param visibleNew (boolean) - should new category be visible after creation.
     */
    @Override public boolean updateFavorite(net.osmand.aidlapi.favorite.UpdateFavoriteParams params) throws android.os.RemoteException
    {
      return false;
    }
    /** Start gpx recording. */
    @Override public boolean startGpxRecording(net.osmand.aidlapi.gpx.StartGpxRecordingParams params) throws android.os.RemoteException
    {
      return false;
    }
    /** Stop gpx recording. */
    @Override public boolean stopGpxRecording(net.osmand.aidlapi.gpx.StopGpxRecordingParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Take photo note.
     * 
     * @param lat (double) - latutude of photo note.
     * @param lon (double) - longitude of photo note.
     */
    @Override public boolean takePhotoNote(net.osmand.aidlapi.note.TakePhotoNoteParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Start video note recording.
     * 
     * @param lat (double) - latutude of video note point.
     * @param lon (double) - longitude of video note point.
     */
    @Override public boolean startVideoRecording(net.osmand.aidlapi.note.StartVideoRecordingParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Start audio note recording.
     * 
     * @param lat (double) - latutude of audio note point.
     * @param lon (double) - longitude of audio note point.
     */
    @Override public boolean startAudioRecording(net.osmand.aidlapi.note.StartAudioRecordingParams params) throws android.os.RemoteException
    {
      return false;
    }
    /** Stop Audio/Video recording. */
    @Override public boolean stopRecording(net.osmand.aidlapi.note.StopRecordingParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Start navigation.
     * 
     * @param startName (String) - name of the start point as it displays in OsmAnd's UI. Nullable.
     * @param startLat (double) - latitude of the start point. If 0 - current location is used.
     * @param startLon (double) - longitude of the start point. If 0 - current location is used.
     * @param destName (String) - name of the start point as it displays in OsmAnd's UI.
     * @param destLat (double) - latitude of a destination point.
     * @param destLon (double) - longitude of a destination point.
     * @param profile (String)  - One of: "default", "car", "bicycle", "pedestrian", "aircraft", "boat", "hiking", "motorcycle", "truck". Nullable (default).
     * @param force (boolean) - ask to stop current navigation if any. False - ask. True - don't ask.
     */
    @Override public boolean navigate(net.osmand.aidlapi.navigation.NavigateParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Start navigation using gpx file. User need to grant Uri permission to OsmAnd.
     * 
     * @param gpxUri (Uri) - URI created by FileProvider.
     * @param force (boolean) - ask to stop current navigation if any. False - ask. True - don't ask.
     */
    @Override public boolean navigateGpx(net.osmand.aidlapi.navigation.NavigateGpxParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Remove GPX file.
     * 
     * @param fileName (String) - file name to remove;
     */
    @Override public boolean removeGpx(net.osmand.aidlapi.gpx.RemoveGpxParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Show AMapPoint on map in OsmAnd.
     * 
     * @param layerId (String) - layer id. Note: layer should be added first.
     * @param pointId (String) - point id.
     * @param shortName (String) - short name (single char). Displayed on the map.
     * @param fullName (String) - full name. Displayed in the context menu on first row.
     * @param typeName (String) - type name. Displayed in context menu on second row.
     * @param color (int) - color of circle's background.
     * @param location (ALatLon) - location of the point.
     * @param details List<String> - list of details. Displayed under context menu.
     * @param params Map<String, String> - optional map of params for point.
     */
    @Override public boolean showMapPoint(net.osmand.aidlapi.maplayer.point.ShowMapPointParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Method for adding up to 3 items to the OsmAnd navigation drawer.
     * 
     * @param appPackage - current application package.
     * @param names - list of names for items.
     * @param uris - list of uris for intents.
     * @param iconNames - list of icon names for items.
     * @param flags - list of flags for intents. Use -1 if no flags needed.
     */
    @Override public boolean setNavDrawerItems(net.osmand.aidlapi.navdrawer.SetNavDrawerItemsParams params) throws android.os.RemoteException
    {
      return false;
    }
    /** Put navigation on pause. */
    @Override public boolean pauseNavigation(net.osmand.aidlapi.navigation.PauseNavigationParams params) throws android.os.RemoteException
    {
      return false;
    }
    /** Resume navigation if it was paused before. */
    @Override public boolean resumeNavigation(net.osmand.aidlapi.navigation.ResumeNavigationParams params) throws android.os.RemoteException
    {
      return false;
    }
    /** Stop navigation. Removes target / intermediate points and route path from the map. */
    @Override public boolean stopNavigation(net.osmand.aidlapi.navigation.StopNavigationParams params) throws android.os.RemoteException
    {
      return false;
    }
    /** Mute voice guidance. Stays muted until unmute manually or via the api. */
    @Override public boolean muteNavigation(net.osmand.aidlapi.navigation.MuteNavigationParams params) throws android.os.RemoteException
    {
      return false;
    }
    /** Unmute voice guidance. */
    @Override public boolean unmuteNavigation(net.osmand.aidlapi.navigation.UnmuteNavigationParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Run search for POI / Address.
     * 
     * @param searchQuery (String) - search query string.
     * @param searchType (int) - type of search. Values:
     *                   SearchParams.SEARCH_TYPE_ALL - all kind of search
     *                   SearchParams.SEARCH_TYPE_POI - POIs only
     *                   SearchParams.SEARCH_TYPE_ADDRESS - addresses only
     * 
     * @param latitude (double) - latitude of original search location.
     * @param longitude (double) - longitude of original search location.
     * @param radiusLevel (int) - value from 1 to 7. Default value = 1.
     * @param totalLimit (int) - limit of returned search result rows. Default value = -1 (unlimited).
     */
    @Override public boolean search(net.osmand.aidlapi.search.SearchParams params, net.osmand.aidlapi.IOsmAndAidlCallback callback) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Do search and start navigation.
     * 
     * @param startName (String) - name of the start point as it displays in OsmAnd's UI. Nullable.
     * @param startLat (double) - latitude of the start point. If 0 - current location is used.
     * @param startLon (double) - longitude of the start point. If 0 - current location is used.
     * @param searchQuery (String) - Text of a query for searching a destination point. Sent as URI parameter.
     * @param searchLat (double) - original location of search (latitude). Sent as URI parameter.
     * @param searchLon (double) - original location of search (longitude). Sent as URI parameter.
     * @param profile (String) - one of: "default", "car", "bicycle", "pedestrian", "aircraft", "boat", "hiking", "motorcycle", "truck". Nullable (default).
     * @param force (boolean) - ask to stop current navigation if any. False - ask. True - don't ask.
     */
    @Override public boolean navigateSearch(net.osmand.aidlapi.navigation.NavigateSearchParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Method to register for periodical callbacks from OsmAnd
     * 
     * @param updateTimeMS (long)- period of time in millisecond after which callback is triggered
     * @param callback (IOsmAndCallback)- create and provide instance of {@link IOsmAndAidlCallback} interface
     * @return id (long) - id of callback in OsmAnd. Needed to unsubscribe from updates.
     */
    @Override public long registerForUpdates(long updateTimeMS, net.osmand.aidlapi.IOsmAndAidlCallback callback) throws android.os.RemoteException
    {
      return 0L;
    }
    /**
     * Method to unregister from periodical callbacks from OsmAnd
     * 
     * @param callbackId (long)- id of registered callback (provided by OsmAnd
     * in {@link OsmAndAidlHelper#registerForUpdates(long, IOsmAndAidlCallback)})
     */
    @Override public boolean unregisterFromUpdates(long callbackId) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Method for adding image to the top of Osmand's NavDrawer.
     * 
     * @param imageUri (String)- image's URI.toString
     * 
     * @deprecated
     * Use the {@link #setNavDrawerLogoWithParams(NavDrawerHeaderParams params)} method.
     */
    @Override public boolean setNavDrawerLogo(java.lang.String imageUri) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Method for selected UI elements (like QuickSearch button) to show.
     * 
     * @param ids (List<String>)- list of menu items keys from {@link OsmAndCustomizationConstants}
     */
    @Override public boolean setEnabledIds(java.util.List<java.lang.String> ids) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Method for selected UI elements (like QuickSearch button) to hide.
     * 
     * @param ids (List<String>)- list of menu items keys from {@link OsmAndCustomizationConstants}
     */
    @Override public boolean setDisabledIds(java.util.List<java.lang.String> ids) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Method to show selected NavDrawer's menu items.
     * 
     * @param patterns (List<String>) - list of menu items names from {@link OsmAndCustomizationConstants}
     */
    @Override public boolean setEnabledPatterns(java.util.List<java.lang.String> patterns) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Method to hide selected NavDrawer's menu items.
     * 
     * @param patterns (List<String>)- list of menu items names from {@link OsmAndCustomizationConstants}
     */
    @Override public boolean setDisabledPatterns(java.util.List<java.lang.String> patterns) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Register OsmAnd widgets for visibility.
     * 
     * @param widgetKey ()- widget id.
     * @param appModKeys - list of OsmAnd Application modes widget active with. Could be "null" for all modes.
     */
    @Override public boolean regWidgetVisibility(net.osmand.aidlapi.customization.SetWidgetsParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Register OsmAnd widgets for availability.
     * 
     * @param widgetKey (String) - widget id.
     * @param appModKeys (List<String>)- ist of OsmAnd Application modes widget active with. Could be "null" for all modes.
     */
    @Override public boolean regWidgetAvailability(net.osmand.aidlapi.customization.SetWidgetsParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Add custom parameters for OsmAnd settings to associate with client app.
     * 
     * @param sharedPreferencesName (String)- string with name of clint's app for shared preferences key
     * @param bundle (Bundle)- bundle with keys from Settings IDs {@link OsmAndCustomizationConstants} and Settings params
     */
    @Override public boolean customizeOsmandSettings(net.osmand.aidlapi.customization.OsmandSettingsParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Method to get list of gpx files currently registered (imported or created) in OsmAnd;
     * 
     * @return list of gpx files
     */
    @Override public boolean getImportedGpx(java.util.List<net.osmand.aidlapi.gpx.AGpxFile> files) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Method to get list of sqlitedb files registered in OsmAnd;
     * 
     * @return list of sqlitedb files
     */
    @Override public boolean getSqliteDbFiles(java.util.List<net.osmand.aidlapi.tiles.ASqliteDbFile> files) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Method to get list of currently active sqlitedb files
     * 
     * @return list of sqlitedb files
     */
    @Override public boolean getActiveSqliteDbFiles(java.util.List<net.osmand.aidlapi.tiles.ASqliteDbFile> files) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Method to show selected sqlitedb file as map overlay.
     * 
     * @param fileName (String) - name of sqlitedb file
     */
    @Override public boolean showSqliteDbFile(java.lang.String fileName) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Method to hide sqlitedb file from map overlay.
     * 
     * @param fileName (String) - name of sqlitedb file
     */
    @Override public boolean hideSqliteDbFile(java.lang.String fileName) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Method for adding image to the top of OsmAnd's NavDrawer with additional params
     * 
     * @param imageUri (String) - image's URI.toString
     * @param packageName (String) - client's app package name
     * @param intent (String) - intent for additional functionality on image click
     */
    @Override public boolean setNavDrawerLogoWithParams(net.osmand.aidlapi.navdrawer.NavDrawerHeaderParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Method for adding functionality to "Powered by Osmand" logo in NavDrawer's footer
     * (reset OsmAnd settings to pre-clinet app's state)
     * 
     * @param packageName (String) - package name
     * @param intent (String) - intent
     * @param appName (String) - client's app name
     */
    @Override public boolean setNavDrawerFooterWithParams(net.osmand.aidlapi.navdrawer.NavDrawerFooterParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Restore default (pre-client) OsmAnd settings and state:
     * clears features, widgets and settings customization, NavDraw logo.
     */
    @Override public boolean restoreOsmand() throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Method to change state of plug-ins in OsmAnd.
     * 
     * @param pluginId (String) - id (name) of plugin.
     * @param newState (int) - new state (0 - off, 1 - on).
     */
    @Override public boolean changePluginState(net.osmand.aidlapi.plugins.PluginParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Method to register for callback on OsmAnd initialization
     * @param callback (IOsmAndAidlCallback) - create and provide instance of {@link IOsmAndAidlCallback} interface
     */
    @Override public boolean registerForOsmandInitListener(net.osmand.aidlapi.IOsmAndAidlCallback callback) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Requests bitmap snap-shot of map with GPX file from provided URI in its center.
     * You can set bitmap size, density and GPX lines color, but you need
     * to manually download appropriate map in OsmAnd or background will be empty.
     * Bitmap will be returned through callback {@link IOsmAndAidlCallback#onGpxBitmapCreated(AGpxBitmap)}
     * 
     * @param gpxUri (Uri/File) - Uri for gpx file
     * @param density (float) - image density. Recommended to use default metrics for device's display.
     * @param widthPixels (int) - width of bitmap
     * @param heightPixels (int) - height of bitmap
     * @param color (int) - color in ARGB format
     * @param callback (IOsmAndAidlCallback) - instance of callback from OsmAnd.
     */
    @Override public boolean getBitmapForGpx(net.osmand.aidlapi.gpx.CreateGpxBitmapParams file, net.osmand.aidlapi.IOsmAndAidlCallback callback) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Method to copy files to OsmAnd part by part. For now supports only sqlitedb format.
     * Part size (bytearray) should not exceed 256k.
     * 
     * @param fileName (String) - name of file
     * @param filePartData (byte[]) - parts of file, byte[] with size 256k or less.
     * @param startTime (long) - timestamp of copying start.
     * @param isDone (boolean) - boolean to mark end of copying.
     * @return number of last successfully received file part or error(-1).
     */
    @Override public int copyFile(net.osmand.aidlapi.copyfile.CopyFileParams filePart) throws android.os.RemoteException
    {
      return 0;
    }
    /**
     * Method to register for updates during navgation. Notifies user about distance to the next turn and its type.
     * 
     * @param subscribeToUpdates (boolean) - subscribe or unsubscribe from updates
     * @param callbackId (long) - id of callback, needed to unsubscribe from updates
     * @param callback (IOsmAndAidlCallback) - callback to notify user on navigation data change
     */
    @Override public long registerForNavigationUpdates(net.osmand.aidlapi.navigation.ANavigationUpdateParams params, net.osmand.aidlapi.IOsmAndAidlCallback callback) throws android.os.RemoteException
    {
      return 0L;
    }
    /**
     * Method to add Context Menu buttons to OsmAnd Context menu.
     * 
     * {@link ContextMenuButtonsParams } is a wrapper class for params:
     * 
     * @param leftButton (AContextMenuButton) - parameters for left context button:
     * @param buttonId (String at AContextMenuButton) - id of button in View
     * @param leftTextCaption (String at AContextMenuButton) - left-side button text
     * @param rightTextCaption (String at AContextMenuButton) - right-side button text
     * @param String leftIconName (String at AContextMenuButton) - name of left-side icon
     * @param String rightIconName (String at AContextMenuButton) - name of right-side icon
     * @param boolean needColorizeIcon (booleanat AContextMenuButton) - flag to apply color to icon
     * @param boolean enabled (boolean at AContextMenuButton) - enable button flag
     * 
     * @param rightButton (AContextMenuButton) - parameters for right context button, see <i>leftButton</i> param for details.
     * @param id (String) - button id;
     * @param appPackage (String) - clinet's app package name
     * @param layerId (String) - id of Osmand's map layer
     * @param callbackId (long) - {@link IOsmAndAidlCallback} id
     * @param pointsIds (List<String>) - list of point Ids to which this rules applies to.
     * 
     * @param callback (IOsmAndAidlCallback) - AIDL callback;
     * 
     * @return long - callback's Id;
     */
    @Override public long addContextMenuButtons(net.osmand.aidlapi.contextmenu.ContextMenuButtonsParams params, net.osmand.aidlapi.IOsmAndAidlCallback callback) throws android.os.RemoteException
    {
      return 0L;
    }
    /**
     * Method to remove Context Menu buttons from OsmAnd Context menu.
     * 
     * {@link RemoveContextMenuButtonsParams} is a wrapper class for params:
     * 
     * @param paramsId (String) - id of {@link ContextMenuButtonsParams} of button you want to remove;
     * @param callbackId (long) - id of {@ling IOsmAndAidlCallback} of button you want to remove;
     */
    @Override public boolean removeContextMenuButtons(net.osmand.aidlapi.contextmenu.RemoveContextMenuButtonsParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Method to update params on already set custom Context Button.
     * 
     * {@link UpdateContextMenuButtonsParams } is a wrapper class for params:
     * 
     * @param leftButton (AContextMenuButton) - parameters for left context button:
     * @param buttonId (String at AContextMenuButton) - id of button in View
     * @param leftTextCaption (String at AContextMenuButton) - left-side button text
     * @param rightTextCaption (String at AContextMenuButton) - right-side button text
     * @param String leftIconName (String at AContextMenuButton) - name of left-side icon
     * @param String rightIconName (String at AContextMenuButton) - name of right-side icon
     * @param boolean needColorizeIcon (booleanat AContextMenuButton) - flag to apply color to icon
     * @param boolean enabled (boolean at AContextMenuButton) - enable button flag
     * 
     * @param rightButton (AContextMenuButton) - parameters for right context button, see <i>leftButton</i> param for details.
     * @param id (String) - button id;
     * @param appPackage (String) - clinet's app package name
     * @param layerId (String) - id of Osmand's map layer
     * @param callbackId (long) - {@link IOsmAndAidlCallback} id
     * @param pointsIds (List<String>) - list of point Ids to which this rules applies to.
     */
    @Override public boolean updateContextMenuButtons(net.osmand.aidlapi.contextmenu.UpdateContextMenuButtonsParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Method to check if there is a customized setting in OsmAnd Settings.
     * 
     * {@link OsmandSettingsInfoParams} is a wrapper class for params:
     * 
     * @param sharedPreferencesName (String at OsmandSettingInfoParams) - key of setting in OsmAnd's preferences.
     * 
     * @return boolean - true if setting is already set in SharedPreferences
     */
    @Override public boolean areOsmandSettingsCustomized(net.osmand.aidlapi.customization.OsmandSettingsInfoParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Method to customize parameters of OsmAnd.
     * 
     * @param params (CustomizationInfoParams) - wrapper class for custom settings and ui.
     * 
     * @param settingsParams (OsmandSettingsParams) - wrapper class for OsmAnd shared preferences params.
     * 			   See {@link #customizeOsmandSettings(in OsmandSettingsParams params) customizeOsmandSettings}
     * 			   method description for details.
     * @param navDrawerHeaderParams (NavDrawerHeaderParams) - wrapper class for OsmAnd navdrawer header params.
     * 			   See {@link #setNavDrawerLogoWithParams(in NavDrawerHeaderParams params) setNavDrawerLogoWithParams}
     * 			   method description for details.
     * @param navDrawerFooterParams (NavDrawerFooterParams) - wrapper class for OsmAnd navdrawer footer params.
     * 			   See {@link #setNavDrawerFooterWithParams(in NavDrawerFooterParams params) setNavDrawerFooterWithParams}
     * 			   method description for details.
     * @param visibilityWidgetsParams (ArrayList<SetWidgetsParams>) - wrapper class for OsmAnd widgets visibility.
     * 			   See {@link #regWidgetVisibility(in SetWidgetsParams params) regWidgetVisibility}
     * 			   method description for details.
     * @param availabilityWidgetsParams (ArrayList<SetWidgetsParams>) - wrapper class for OsmAnd widgets availability.
     * 			   See {@link #regWidgetAvailability(in SetWidgetsParams params) regWidgetAvailability}
     * 			   method description for details.
     * @param pluginsParams (ArrayList<PluginParams>) - wrapper class for OsmAnd plugins states params.
     * 			   See {@link #changePluginState(in PluginParams params) changePluginState}
     * 			   method description for details.
     * @param featuresEnabledIds (List<String>) - list of UI elements (like QuickSearch button) to show.
     * 			   See {@link #setEnabledIds(in List<String> ids) setEnabledIds}
     * @param featuresDisabledIds (List<String>) - list of UI elements (like QuickSearch button) to hide.
     * 			   See {@link #setDisabledIds(in List<String> ids) setDisabledIds}
     * @param featuresEnabledPatterns (List<String>) - list of NavDrawer menu items to show.
     * 			   See {@link #setEnabledPatterns(in List<String> patterns) setEnabledPatterns}
     * @param featuresDisabledPatterns (List<String>) - list of NavDrawer menu items to hide.
     * 			   See {@link #setDisabledPatterns(in List<String> patterns) setDisabledPatterns}
     */
    @Override public boolean setCustomization(net.osmand.aidlapi.customization.CustomizationInfoParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Method to register for Voice Router voice messages during navigation. Notifies user about voice messages.
     * 
     * @params subscribeToUpdates (boolean) - boolean flag to subscribe or unsubscribe from messages
     * @params callbackId (long) - id of callback, needed to unsubscribe from messages
     * @params callback (IOsmAndAidlCallback) - callback to notify user on voice message
     */
    @Override public long registerForVoiceRouterMessages(net.osmand.aidlapi.navigation.ANavigationVoiceRouterMessageParams params, net.osmand.aidlapi.IOsmAndAidlCallback callback) throws android.os.RemoteException
    {
      return 0L;
    }
    /**
     * Removes all active map markers (marks them as passed and moves to history)
     * Empty class of params
     */
    @Override public boolean removeAllActiveMapMarkers(net.osmand.aidlapi.mapmarker.RemoveMapMarkersParams params) throws android.os.RemoteException
    {
      return false;
    }
    @Override public boolean importProfile(net.osmand.aidlapi.customization.ProfileSettingsParams params) throws android.os.RemoteException
    {
      return false;
    }
    @Override public boolean executeQuickAction(net.osmand.aidlapi.quickaction.QuickActionParams params) throws android.os.RemoteException
    {
      return false;
    }
    @Override public boolean getQuickActionsInfo(java.util.List<net.osmand.aidlapi.quickaction.QuickActionInfoParams> quickActions) throws android.os.RemoteException
    {
      return false;
    }
    /** Toggle Lock/Unlock screen. */
    @Override public boolean setLockState(net.osmand.aidlapi.lock.SetLockStateParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Method to register for  key events.
     * 
     * @params subscribeToUpdates (boolean) - boolean flag to subscribe or unsubscribe from key events
     * @params callbackId (long) - id of callback, needed to unsubscribe key events
     * @params callback (IOsmAndAidlCallback) - callback to notify user on key event
     * @params keyEventList (List<Integer>) - list of requested key events
     */
    @Override public long registerForKeyEvents(net.osmand.aidlapi.events.AKeyEventsParams params, net.osmand.aidlapi.IOsmAndAidlCallback callback) throws android.os.RemoteException
    {
      return 0L;
    }
    @Override public net.osmand.aidlapi.info.AppInfoParams getAppInfo() throws android.os.RemoteException
    {
      return null;
    }
    @Override public boolean setMapMargins(net.osmand.aidlapi.customization.MapMarginsParams params) throws android.os.RemoteException
    {
      return false;
    }
    @Override public boolean exportProfile(net.osmand.aidlapi.profile.ExportProfileParams params) throws android.os.RemoteException
    {
      return false;
    }
    /** Is any fragment open. */
    @Override public boolean isFragmentOpen() throws android.os.RemoteException
    {
      return false;
    }
    /** Is contect menu open. */
    @Override public boolean isMenuOpen() throws android.os.RemoteException
    {
      return false;
    }
    @Override public int getPluginVersion(net.osmand.aidlapi.customization.CustomPluginParams params) throws android.os.RemoteException
    {
      return 0;
    }
    @Override public boolean selectProfile(net.osmand.aidlapi.customization.SelectProfileParams params) throws android.os.RemoteException
    {
      return false;
    }
    @Override public boolean getProfiles(java.util.List<net.osmand.aidlapi.customization.AProfile> profiles) throws android.os.RemoteException
    {
      return false;
    }
    @Override public boolean getBlockedRoads(java.util.List<net.osmand.aidlapi.navigation.ABlockedRoad> blockedRoads) throws android.os.RemoteException
    {
      return false;
    }
    @Override public boolean addRoadBlock(net.osmand.aidlapi.navigation.AddBlockedRoadParams params) throws android.os.RemoteException
    {
      return false;
    }
    @Override public boolean removeRoadBlock(net.osmand.aidlapi.navigation.RemoveBlockedRoadParams params) throws android.os.RemoteException
    {
      return false;
    }
    @Override public boolean setLocation(net.osmand.aidlapi.map.SetLocationParams params) throws android.os.RemoteException
    {
      return false;
    }
    @Override public boolean exitApp(net.osmand.aidlapi.exit.ExitAppParams params) throws android.os.RemoteException
    {
      return false;
    }
    @Override public boolean getText(net.osmand.aidlapi.info.GetTextParams params) throws android.os.RemoteException
    {
      return false;
    }
    @Override public boolean reloadIndexes() throws android.os.RemoteException
    {
      return false;
    }
    @Override public boolean setPreference(net.osmand.aidlapi.customization.PreferenceParams params) throws android.os.RemoteException
    {
      return false;
    }
    @Override public boolean getPreference(net.osmand.aidlapi.customization.PreferenceParams params) throws android.os.RemoteException
    {
      return false;
    }
    /**
     * Method to register for Logcat messages. Notifies user about new logs in application.
     * 
     * @param subscribeToUpdates (boolean) - boolean flag to subscribe or unsubscribe from messages
     * @param callbackId (long) - id of callback, needed to unsubscribe from messages
     * @param filterLevel (String) determines which type of logs will be returned by callback
     * Must be one of the values below:
     * - "D" (debug)
     * - "I" (info)
     * - "W" (warn)
     * - "E" (error)
     * @param callback (IOsmAndAidlCallback) - callback to notify user on new OsmAnd logs
     */
    @Override public long registerForLogcatMessages(net.osmand.aidlapi.logcat.ALogcatListenerParams params, net.osmand.aidlapi.IOsmAndAidlCallback callback) throws android.os.RemoteException
    {
      return 0L;
    }
    @Override public boolean setZoomLimits(net.osmand.aidlapi.customization.ZoomLimitsParams params) throws android.os.RemoteException
    {
      return false;
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements net.osmand.aidlapi.IOsmAndAidlInterface
  {
    /** Construct the stub at attach it to the interface. */
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an net.osmand.aidlapi.IOsmAndAidlInterface interface,
     * generating a proxy if needed.
     */
    public static net.osmand.aidlapi.IOsmAndAidlInterface asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof net.osmand.aidlapi.IOsmAndAidlInterface))) {
        return ((net.osmand.aidlapi.IOsmAndAidlInterface)iin);
      }
      return new net.osmand.aidlapi.IOsmAndAidlInterface.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      switch (code)
      {
        case INTERFACE_TRANSACTION:
        {
          reply.writeString(descriptor);
          return true;
        }
      }
      switch (code)
      {
        case TRANSACTION_addMapMarker:
        {
          net.osmand.aidlapi.mapmarker.AddMapMarkerParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.mapmarker.AddMapMarkerParams.CREATOR);
          boolean _result = this.addMapMarker(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_removeMapMarker:
        {
          net.osmand.aidlapi.mapmarker.RemoveMapMarkerParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.mapmarker.RemoveMapMarkerParams.CREATOR);
          boolean _result = this.removeMapMarker(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_updateMapMarker:
        {
          net.osmand.aidlapi.mapmarker.UpdateMapMarkerParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.mapmarker.UpdateMapMarkerParams.CREATOR);
          boolean _result = this.updateMapMarker(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_addMapWidget:
        {
          net.osmand.aidlapi.mapwidget.AddMapWidgetParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.mapwidget.AddMapWidgetParams.CREATOR);
          boolean _result = this.addMapWidget(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_removeMapWidget:
        {
          net.osmand.aidlapi.mapwidget.RemoveMapWidgetParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.mapwidget.RemoveMapWidgetParams.CREATOR);
          boolean _result = this.removeMapWidget(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_updateMapWidget:
        {
          net.osmand.aidlapi.mapwidget.UpdateMapWidgetParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.mapwidget.UpdateMapWidgetParams.CREATOR);
          boolean _result = this.updateMapWidget(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_addMapPoint:
        {
          net.osmand.aidlapi.maplayer.point.AddMapPointParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.maplayer.point.AddMapPointParams.CREATOR);
          boolean _result = this.addMapPoint(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_removeMapPoint:
        {
          net.osmand.aidlapi.maplayer.point.RemoveMapPointParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.maplayer.point.RemoveMapPointParams.CREATOR);
          boolean _result = this.removeMapPoint(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_updateMapPoint:
        {
          net.osmand.aidlapi.maplayer.point.UpdateMapPointParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.maplayer.point.UpdateMapPointParams.CREATOR);
          boolean _result = this.updateMapPoint(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_addMapLayer:
        {
          net.osmand.aidlapi.maplayer.AddMapLayerParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.maplayer.AddMapLayerParams.CREATOR);
          boolean _result = this.addMapLayer(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_removeMapLayer:
        {
          net.osmand.aidlapi.maplayer.RemoveMapLayerParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.maplayer.RemoveMapLayerParams.CREATOR);
          boolean _result = this.removeMapLayer(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_updateMapLayer:
        {
          net.osmand.aidlapi.maplayer.UpdateMapLayerParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.maplayer.UpdateMapLayerParams.CREATOR);
          boolean _result = this.updateMapLayer(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_importGpx:
        {
          net.osmand.aidlapi.gpx.ImportGpxParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.gpx.ImportGpxParams.CREATOR);
          boolean _result = this.importGpx(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_showGpx:
        {
          net.osmand.aidlapi.gpx.ShowGpxParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.gpx.ShowGpxParams.CREATOR);
          boolean _result = this.showGpx(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_hideGpx:
        {
          net.osmand.aidlapi.gpx.HideGpxParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.gpx.HideGpxParams.CREATOR);
          boolean _result = this.hideGpx(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_getActiveGpx:
        {
          java.util.List<net.osmand.aidlapi.gpx.ASelectedGpxFile> _arg0;
          _arg0 = new java.util.ArrayList<net.osmand.aidlapi.gpx.ASelectedGpxFile>();
          boolean _result = this.getActiveGpx(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          _Parcel.writeTypedList(reply, _arg0, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_setMapLocation:
        {
          net.osmand.aidlapi.map.SetMapLocationParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.map.SetMapLocationParams.CREATOR);
          boolean _result = this.setMapLocation(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_calculateRoute:
        {
          net.osmand.aidlapi.calculateroute.CalculateRouteParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.calculateroute.CalculateRouteParams.CREATOR);
          boolean _result = this.calculateRoute(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_refreshMap:
        {
          boolean _result = this.refreshMap();
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_addFavoriteGroup:
        {
          net.osmand.aidlapi.favorite.group.AddFavoriteGroupParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.favorite.group.AddFavoriteGroupParams.CREATOR);
          boolean _result = this.addFavoriteGroup(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_removeFavoriteGroup:
        {
          net.osmand.aidlapi.favorite.group.RemoveFavoriteGroupParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.favorite.group.RemoveFavoriteGroupParams.CREATOR);
          boolean _result = this.removeFavoriteGroup(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_updateFavoriteGroup:
        {
          net.osmand.aidlapi.favorite.group.UpdateFavoriteGroupParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.favorite.group.UpdateFavoriteGroupParams.CREATOR);
          boolean _result = this.updateFavoriteGroup(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_addFavorite:
        {
          net.osmand.aidlapi.favorite.AddFavoriteParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.favorite.AddFavoriteParams.CREATOR);
          boolean _result = this.addFavorite(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_removeFavorite:
        {
          net.osmand.aidlapi.favorite.RemoveFavoriteParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.favorite.RemoveFavoriteParams.CREATOR);
          boolean _result = this.removeFavorite(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_updateFavorite:
        {
          net.osmand.aidlapi.favorite.UpdateFavoriteParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.favorite.UpdateFavoriteParams.CREATOR);
          boolean _result = this.updateFavorite(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_startGpxRecording:
        {
          net.osmand.aidlapi.gpx.StartGpxRecordingParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.gpx.StartGpxRecordingParams.CREATOR);
          boolean _result = this.startGpxRecording(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_stopGpxRecording:
        {
          net.osmand.aidlapi.gpx.StopGpxRecordingParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.gpx.StopGpxRecordingParams.CREATOR);
          boolean _result = this.stopGpxRecording(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_takePhotoNote:
        {
          net.osmand.aidlapi.note.TakePhotoNoteParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.note.TakePhotoNoteParams.CREATOR);
          boolean _result = this.takePhotoNote(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_startVideoRecording:
        {
          net.osmand.aidlapi.note.StartVideoRecordingParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.note.StartVideoRecordingParams.CREATOR);
          boolean _result = this.startVideoRecording(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_startAudioRecording:
        {
          net.osmand.aidlapi.note.StartAudioRecordingParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.note.StartAudioRecordingParams.CREATOR);
          boolean _result = this.startAudioRecording(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_stopRecording:
        {
          net.osmand.aidlapi.note.StopRecordingParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.note.StopRecordingParams.CREATOR);
          boolean _result = this.stopRecording(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_navigate:
        {
          net.osmand.aidlapi.navigation.NavigateParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.navigation.NavigateParams.CREATOR);
          boolean _result = this.navigate(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_navigateGpx:
        {
          net.osmand.aidlapi.navigation.NavigateGpxParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.navigation.NavigateGpxParams.CREATOR);
          boolean _result = this.navigateGpx(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          _Parcel.writeTypedObject(reply, _arg0, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_removeGpx:
        {
          net.osmand.aidlapi.gpx.RemoveGpxParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.gpx.RemoveGpxParams.CREATOR);
          boolean _result = this.removeGpx(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_showMapPoint:
        {
          net.osmand.aidlapi.maplayer.point.ShowMapPointParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.maplayer.point.ShowMapPointParams.CREATOR);
          boolean _result = this.showMapPoint(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_setNavDrawerItems:
        {
          net.osmand.aidlapi.navdrawer.SetNavDrawerItemsParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.navdrawer.SetNavDrawerItemsParams.CREATOR);
          boolean _result = this.setNavDrawerItems(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_pauseNavigation:
        {
          net.osmand.aidlapi.navigation.PauseNavigationParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.navigation.PauseNavigationParams.CREATOR);
          boolean _result = this.pauseNavigation(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_resumeNavigation:
        {
          net.osmand.aidlapi.navigation.ResumeNavigationParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.navigation.ResumeNavigationParams.CREATOR);
          boolean _result = this.resumeNavigation(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_stopNavigation:
        {
          net.osmand.aidlapi.navigation.StopNavigationParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.navigation.StopNavigationParams.CREATOR);
          boolean _result = this.stopNavigation(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_muteNavigation:
        {
          net.osmand.aidlapi.navigation.MuteNavigationParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.navigation.MuteNavigationParams.CREATOR);
          boolean _result = this.muteNavigation(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_unmuteNavigation:
        {
          net.osmand.aidlapi.navigation.UnmuteNavigationParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.navigation.UnmuteNavigationParams.CREATOR);
          boolean _result = this.unmuteNavigation(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_search:
        {
          net.osmand.aidlapi.search.SearchParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.search.SearchParams.CREATOR);
          net.osmand.aidlapi.IOsmAndAidlCallback _arg1;
          _arg1 = net.osmand.aidlapi.IOsmAndAidlCallback.Stub.asInterface(data.readStrongBinder());
          boolean _result = this.search(_arg0, _arg1);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_navigateSearch:
        {
          net.osmand.aidlapi.navigation.NavigateSearchParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.navigation.NavigateSearchParams.CREATOR);
          boolean _result = this.navigateSearch(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_registerForUpdates:
        {
          long _arg0;
          _arg0 = data.readLong();
          net.osmand.aidlapi.IOsmAndAidlCallback _arg1;
          _arg1 = net.osmand.aidlapi.IOsmAndAidlCallback.Stub.asInterface(data.readStrongBinder());
          long _result = this.registerForUpdates(_arg0, _arg1);
          reply.writeNoException();
          reply.writeLong(_result);
          break;
        }
        case TRANSACTION_unregisterFromUpdates:
        {
          long _arg0;
          _arg0 = data.readLong();
          boolean _result = this.unregisterFromUpdates(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_setNavDrawerLogo:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          boolean _result = this.setNavDrawerLogo(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_setEnabledIds:
        {
          java.util.List<java.lang.String> _arg0;
          _arg0 = data.createStringArrayList();
          boolean _result = this.setEnabledIds(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_setDisabledIds:
        {
          java.util.List<java.lang.String> _arg0;
          _arg0 = data.createStringArrayList();
          boolean _result = this.setDisabledIds(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_setEnabledPatterns:
        {
          java.util.List<java.lang.String> _arg0;
          _arg0 = data.createStringArrayList();
          boolean _result = this.setEnabledPatterns(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_setDisabledPatterns:
        {
          java.util.List<java.lang.String> _arg0;
          _arg0 = data.createStringArrayList();
          boolean _result = this.setDisabledPatterns(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_regWidgetVisibility:
        {
          net.osmand.aidlapi.customization.SetWidgetsParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.customization.SetWidgetsParams.CREATOR);
          boolean _result = this.regWidgetVisibility(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_regWidgetAvailability:
        {
          net.osmand.aidlapi.customization.SetWidgetsParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.customization.SetWidgetsParams.CREATOR);
          boolean _result = this.regWidgetAvailability(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_customizeOsmandSettings:
        {
          net.osmand.aidlapi.customization.OsmandSettingsParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.customization.OsmandSettingsParams.CREATOR);
          boolean _result = this.customizeOsmandSettings(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_getImportedGpx:
        {
          java.util.List<net.osmand.aidlapi.gpx.AGpxFile> _arg0;
          _arg0 = new java.util.ArrayList<net.osmand.aidlapi.gpx.AGpxFile>();
          boolean _result = this.getImportedGpx(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          _Parcel.writeTypedList(reply, _arg0, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_getSqliteDbFiles:
        {
          java.util.List<net.osmand.aidlapi.tiles.ASqliteDbFile> _arg0;
          _arg0 = new java.util.ArrayList<net.osmand.aidlapi.tiles.ASqliteDbFile>();
          boolean _result = this.getSqliteDbFiles(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          _Parcel.writeTypedList(reply, _arg0, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_getActiveSqliteDbFiles:
        {
          java.util.List<net.osmand.aidlapi.tiles.ASqliteDbFile> _arg0;
          _arg0 = new java.util.ArrayList<net.osmand.aidlapi.tiles.ASqliteDbFile>();
          boolean _result = this.getActiveSqliteDbFiles(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          _Parcel.writeTypedList(reply, _arg0, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_showSqliteDbFile:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          boolean _result = this.showSqliteDbFile(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_hideSqliteDbFile:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          boolean _result = this.hideSqliteDbFile(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_setNavDrawerLogoWithParams:
        {
          net.osmand.aidlapi.navdrawer.NavDrawerHeaderParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.navdrawer.NavDrawerHeaderParams.CREATOR);
          boolean _result = this.setNavDrawerLogoWithParams(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_setNavDrawerFooterWithParams:
        {
          net.osmand.aidlapi.navdrawer.NavDrawerFooterParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.navdrawer.NavDrawerFooterParams.CREATOR);
          boolean _result = this.setNavDrawerFooterWithParams(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_restoreOsmand:
        {
          boolean _result = this.restoreOsmand();
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_changePluginState:
        {
          net.osmand.aidlapi.plugins.PluginParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.plugins.PluginParams.CREATOR);
          boolean _result = this.changePluginState(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_registerForOsmandInitListener:
        {
          net.osmand.aidlapi.IOsmAndAidlCallback _arg0;
          _arg0 = net.osmand.aidlapi.IOsmAndAidlCallback.Stub.asInterface(data.readStrongBinder());
          boolean _result = this.registerForOsmandInitListener(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_getBitmapForGpx:
        {
          net.osmand.aidlapi.gpx.CreateGpxBitmapParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.gpx.CreateGpxBitmapParams.CREATOR);
          net.osmand.aidlapi.IOsmAndAidlCallback _arg1;
          _arg1 = net.osmand.aidlapi.IOsmAndAidlCallback.Stub.asInterface(data.readStrongBinder());
          boolean _result = this.getBitmapForGpx(_arg0, _arg1);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_copyFile:
        {
          net.osmand.aidlapi.copyfile.CopyFileParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.copyfile.CopyFileParams.CREATOR);
          int _result = this.copyFile(_arg0);
          reply.writeNoException();
          reply.writeInt(_result);
          break;
        }
        case TRANSACTION_registerForNavigationUpdates:
        {
          net.osmand.aidlapi.navigation.ANavigationUpdateParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.navigation.ANavigationUpdateParams.CREATOR);
          net.osmand.aidlapi.IOsmAndAidlCallback _arg1;
          _arg1 = net.osmand.aidlapi.IOsmAndAidlCallback.Stub.asInterface(data.readStrongBinder());
          long _result = this.registerForNavigationUpdates(_arg0, _arg1);
          reply.writeNoException();
          reply.writeLong(_result);
          break;
        }
        case TRANSACTION_addContextMenuButtons:
        {
          net.osmand.aidlapi.contextmenu.ContextMenuButtonsParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.contextmenu.ContextMenuButtonsParams.CREATOR);
          net.osmand.aidlapi.IOsmAndAidlCallback _arg1;
          _arg1 = net.osmand.aidlapi.IOsmAndAidlCallback.Stub.asInterface(data.readStrongBinder());
          long _result = this.addContextMenuButtons(_arg0, _arg1);
          reply.writeNoException();
          reply.writeLong(_result);
          break;
        }
        case TRANSACTION_removeContextMenuButtons:
        {
          net.osmand.aidlapi.contextmenu.RemoveContextMenuButtonsParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.contextmenu.RemoveContextMenuButtonsParams.CREATOR);
          boolean _result = this.removeContextMenuButtons(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_updateContextMenuButtons:
        {
          net.osmand.aidlapi.contextmenu.UpdateContextMenuButtonsParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.contextmenu.UpdateContextMenuButtonsParams.CREATOR);
          boolean _result = this.updateContextMenuButtons(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_areOsmandSettingsCustomized:
        {
          net.osmand.aidlapi.customization.OsmandSettingsInfoParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.customization.OsmandSettingsInfoParams.CREATOR);
          boolean _result = this.areOsmandSettingsCustomized(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_setCustomization:
        {
          net.osmand.aidlapi.customization.CustomizationInfoParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.customization.CustomizationInfoParams.CREATOR);
          boolean _result = this.setCustomization(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_registerForVoiceRouterMessages:
        {
          net.osmand.aidlapi.navigation.ANavigationVoiceRouterMessageParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.navigation.ANavigationVoiceRouterMessageParams.CREATOR);
          net.osmand.aidlapi.IOsmAndAidlCallback _arg1;
          _arg1 = net.osmand.aidlapi.IOsmAndAidlCallback.Stub.asInterface(data.readStrongBinder());
          long _result = this.registerForVoiceRouterMessages(_arg0, _arg1);
          reply.writeNoException();
          reply.writeLong(_result);
          break;
        }
        case TRANSACTION_removeAllActiveMapMarkers:
        {
          net.osmand.aidlapi.mapmarker.RemoveMapMarkersParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.mapmarker.RemoveMapMarkersParams.CREATOR);
          boolean _result = this.removeAllActiveMapMarkers(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_importProfile:
        {
          net.osmand.aidlapi.customization.ProfileSettingsParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.customization.ProfileSettingsParams.CREATOR);
          boolean _result = this.importProfile(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_executeQuickAction:
        {
          net.osmand.aidlapi.quickaction.QuickActionParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.quickaction.QuickActionParams.CREATOR);
          boolean _result = this.executeQuickAction(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_getQuickActionsInfo:
        {
          java.util.List<net.osmand.aidlapi.quickaction.QuickActionInfoParams> _arg0;
          _arg0 = new java.util.ArrayList<net.osmand.aidlapi.quickaction.QuickActionInfoParams>();
          boolean _result = this.getQuickActionsInfo(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          _Parcel.writeTypedList(reply, _arg0, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_setLockState:
        {
          net.osmand.aidlapi.lock.SetLockStateParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.lock.SetLockStateParams.CREATOR);
          boolean _result = this.setLockState(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_registerForKeyEvents:
        {
          net.osmand.aidlapi.events.AKeyEventsParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.events.AKeyEventsParams.CREATOR);
          net.osmand.aidlapi.IOsmAndAidlCallback _arg1;
          _arg1 = net.osmand.aidlapi.IOsmAndAidlCallback.Stub.asInterface(data.readStrongBinder());
          long _result = this.registerForKeyEvents(_arg0, _arg1);
          reply.writeNoException();
          reply.writeLong(_result);
          break;
        }
        case TRANSACTION_getAppInfo:
        {
          net.osmand.aidlapi.info.AppInfoParams _result = this.getAppInfo();
          reply.writeNoException();
          _Parcel.writeTypedObject(reply, _result, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_setMapMargins:
        {
          net.osmand.aidlapi.customization.MapMarginsParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.customization.MapMarginsParams.CREATOR);
          boolean _result = this.setMapMargins(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_exportProfile:
        {
          net.osmand.aidlapi.profile.ExportProfileParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.profile.ExportProfileParams.CREATOR);
          boolean _result = this.exportProfile(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_isFragmentOpen:
        {
          boolean _result = this.isFragmentOpen();
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_isMenuOpen:
        {
          boolean _result = this.isMenuOpen();
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_getPluginVersion:
        {
          net.osmand.aidlapi.customization.CustomPluginParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.customization.CustomPluginParams.CREATOR);
          int _result = this.getPluginVersion(_arg0);
          reply.writeNoException();
          reply.writeInt(_result);
          break;
        }
        case TRANSACTION_selectProfile:
        {
          net.osmand.aidlapi.customization.SelectProfileParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.customization.SelectProfileParams.CREATOR);
          boolean _result = this.selectProfile(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_getProfiles:
        {
          java.util.List<net.osmand.aidlapi.customization.AProfile> _arg0;
          _arg0 = new java.util.ArrayList<net.osmand.aidlapi.customization.AProfile>();
          boolean _result = this.getProfiles(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          _Parcel.writeTypedList(reply, _arg0, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_getBlockedRoads:
        {
          java.util.List<net.osmand.aidlapi.navigation.ABlockedRoad> _arg0;
          _arg0 = new java.util.ArrayList<net.osmand.aidlapi.navigation.ABlockedRoad>();
          boolean _result = this.getBlockedRoads(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          _Parcel.writeTypedList(reply, _arg0, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_addRoadBlock:
        {
          net.osmand.aidlapi.navigation.AddBlockedRoadParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.navigation.AddBlockedRoadParams.CREATOR);
          boolean _result = this.addRoadBlock(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_removeRoadBlock:
        {
          net.osmand.aidlapi.navigation.RemoveBlockedRoadParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.navigation.RemoveBlockedRoadParams.CREATOR);
          boolean _result = this.removeRoadBlock(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_setLocation:
        {
          net.osmand.aidlapi.map.SetLocationParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.map.SetLocationParams.CREATOR);
          boolean _result = this.setLocation(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_exitApp:
        {
          net.osmand.aidlapi.exit.ExitAppParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.exit.ExitAppParams.CREATOR);
          boolean _result = this.exitApp(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_getText:
        {
          net.osmand.aidlapi.info.GetTextParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.info.GetTextParams.CREATOR);
          boolean _result = this.getText(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          _Parcel.writeTypedObject(reply, _arg0, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_reloadIndexes:
        {
          boolean _result = this.reloadIndexes();
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_setPreference:
        {
          net.osmand.aidlapi.customization.PreferenceParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.customization.PreferenceParams.CREATOR);
          boolean _result = this.setPreference(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_getPreference:
        {
          net.osmand.aidlapi.customization.PreferenceParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.customization.PreferenceParams.CREATOR);
          boolean _result = this.getPreference(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          _Parcel.writeTypedObject(reply, _arg0, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_registerForLogcatMessages:
        {
          net.osmand.aidlapi.logcat.ALogcatListenerParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.logcat.ALogcatListenerParams.CREATOR);
          net.osmand.aidlapi.IOsmAndAidlCallback _arg1;
          _arg1 = net.osmand.aidlapi.IOsmAndAidlCallback.Stub.asInterface(data.readStrongBinder());
          long _result = this.registerForLogcatMessages(_arg0, _arg1);
          reply.writeNoException();
          reply.writeLong(_result);
          break;
        }
        case TRANSACTION_setZoomLimits:
        {
          net.osmand.aidlapi.customization.ZoomLimitsParams _arg0;
          _arg0 = _Parcel.readTypedObject(data, net.osmand.aidlapi.customization.ZoomLimitsParams.CREATOR);
          boolean _result = this.setZoomLimits(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements net.osmand.aidlapi.IOsmAndAidlInterface
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      /**
       * Add map marker at given location.
       * 
       * @param lat (double) -  latitude.
       * @param lon (double) - longitude.
       * @param name (String)- name of marker.
       */
      @Override public boolean addMapMarker(net.osmand.aidlapi.mapmarker.AddMapMarkerParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_addMapMarker, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Remove map marker.
       * 
       * If ignoreCoordinates is false the marker is only removed if lat/lon match the currently set values of the marker.
       * If ignoreCoordinates is true the marker is removed if the name matches, the values of lat/lon are ignored.
       * 
       * @param lat (double) -  latitude.
       * @param lon (double) - longitude.
       * @param name (String)- name of marker.
       * @param ignoreCoordinates (boolean) - flag to determine whether lat/lon shall be ignored
       */
      @Override public boolean removeMapMarker(net.osmand.aidlapi.mapmarker.RemoveMapMarkerParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_removeMapMarker, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Update map marker.
       * 
       * If ignoreCoordinates is false the marker gets updated only if latPrev/lonPrev match the currently set values of the marker.
       * If ignoreCoordinates is true the marker gets updated if the name matches, the values of latPrev/lonPrev are ignored.
       * 
       * @param latPrev (double) - latitude (current marker).
       * @param lonPrev (double) - longitude (current marker).
       * @param namePrev (String) - name (current marker).
       * @param latNew (double) - latitude (new marker).
       * @param lonNew (double) - longitude (new marker).
       * @param nameNew (String) - name (new marker).
       * @param ignoreCoordinates (boolean) - flag to determine whether latPrev/lonPrev shall be ignored
       */
      @Override public boolean updateMapMarker(net.osmand.aidlapi.mapmarker.UpdateMapMarkerParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_updateMapMarker, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Add map widget to the right side of the main screen.
       * Note: any specified icon should exist in OsmAnd app resources.
       * 
       * @param id (String) - widget id.
       * @param menuIconName (String) - icon name (configure map menu).
       * @param menuTitle (String) - widget name (configure map menu).
       * @param lightIconName (String) - icon name for the light theme (widget).
       * @param darkIconName (String) - icon name for the dark theme (widget).
       * @param text (String) - main widget text.
       * @param description (String) - sub text, like "km/h".
       * @param order (int) - order position in the widgets list.
       * @param intentOnClick (String) - onClick intent. Called after click on widget as startActivity(Intent intent).
       */
      @Override public boolean addMapWidget(net.osmand.aidlapi.mapwidget.AddMapWidgetParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_addMapWidget, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Remove map widget.
       * 
       * @param (String) id - widget id.
       */
      @Override public boolean removeMapWidget(net.osmand.aidlapi.mapwidget.RemoveMapWidgetParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_removeMapWidget, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Update map widget.
       * Note: any specified icon should exist in OsmAnd app resources.
       * 
       * @param id (String) - widget id.
       * @param menuIconName (String) - icon name (configure map menu).
       * @param menuTitle (String) - widget name (configure map menu).
       * @param lightIconName (String) - icon name for the light theme (widget).
       * @param darkIconName (String) - icon name for the dark theme (widget).
       * @param text (String) - main widget text.
       * @param description (String) - sub text, like "km/h".
       * @param order (int) - order position in the widgets list.
       * @param intentOnClick (String) - onClick intent. Called after click on widget as startActivity(Intent intent).
       */
      @Override public boolean updateMapWidget(net.osmand.aidlapi.mapwidget.UpdateMapWidgetParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_updateMapWidget, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Add point to user layer.
       * 
       * @param layerId (String) - layer id. Note: layer should be added first.
       * @param pointId (String) - point id.
       * @param shortName (String) - short name (single char). Displayed on the map.
       * @param fullName (String) - full name. Displayed in the context menu on first row.
       * @param typeName (String) - type name. Displayed in context menu on second row.
       * @param color (int) - color of circle's background.
       * @param location (ALatLon) - location of the point.
       * @param details (List<String>)- list of details. Displayed under context menu.
       * @param params (Map<String, String>) - optional map of params for point.
       */
      @Override public boolean addMapPoint(net.osmand.aidlapi.maplayer.point.AddMapPointParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_addMapPoint, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Remove point.
       * 
       * @param layerId (String) - layer id.
       * @param pointId (String) - point id.
       */
      @Override public boolean removeMapPoint(net.osmand.aidlapi.maplayer.point.RemoveMapPointParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_removeMapPoint, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Update point.
       * 
       * @param layerId (String) - layer id.
       * @param pointId (String) - point id.
       * @param updateOpenedMenuAndMap (boolean) - flag to enable folowing mode and menu updates for point
       * @param shortName (String) - short name (single char). Displayed on the map.
       * @param fullName (String) - full name. Displayed in the context menu on first row.
       * @param typeName (String) - type name. Displayed in context menu on second row.
       * @param color (String) - color of circle's background.
       * @param location (ALatLon)- location of the point.
       * @param details (List<String>) - list of details. Displayed under context menu.
       * @param params (Map<String, String>) - optional map of params for point.
       */
      @Override public boolean updateMapPoint(net.osmand.aidlapi.maplayer.point.UpdateMapPointParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_updateMapPoint, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Add user layer on the map.
       * 
       * @param id (String) - layer id.
       * @param name (String) - layer name.
       * @param zOrder (float) - z-order position of layer. Default value is 5.5f
       * @param points Map<Sting, AMapPoint> - initial list of points. Nullable.
       * @param imagePoints (boolean) - use new style for points on map or not. Also default zoom bounds for new style can be edited.
       */
      @Override public boolean addMapLayer(net.osmand.aidlapi.maplayer.AddMapLayerParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_addMapLayer, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Remove user layer.
       * 
       * @param id (String) - layer id.
       */
      @Override public boolean removeMapLayer(net.osmand.aidlapi.maplayer.RemoveMapLayerParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_removeMapLayer, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Update user layer.
       * 
       * @param id (String) - layer id.
       * @param name (String) - layer name.
       * @param zOrder (float) - z-order position of layer. Default value is 5.5f
       * @param points Map<Sting, AMapPoint> - list of points. Nullable.
       * @param imagePoints (boolean) - use new style for points on map or not. Also default zoom bounds for new style can be edited.
       */
      @Override public boolean updateMapLayer(net.osmand.aidlapi.maplayer.UpdateMapLayerParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_updateMapLayer, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Import GPX file to OsmAnd (from URI or file).
       * 
       * @param gpxUri (Uri) - URI created by FileProvider (preferable method).
       * @param file (File) - File which represents GPX track (not recomended, OsmAnd should have rights to access file location).
       * @param fileName (String) - Destination file name. May contain dirs.
       * @param color (String) - color of gpx. Can be one of: "red", "orange", "lightblue", "blue", "purple",
       *                    "translucent_red", "translucent_orange", "translucent_lightblue",
       *                    "translucent_blue", "translucent_purple"
       * @param show (boolean) - show track on the map after import
       */
      @Override public boolean importGpx(net.osmand.aidlapi.gpx.ImportGpxParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_importGpx, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Show GPX file on map.
       * 
       * @param fileName (String) - file name to show. Must be imported first.
       */
      @Override public boolean showGpx(net.osmand.aidlapi.gpx.ShowGpxParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_showGpx, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Hide GPX file.
       * 
       * @param fileName (String) - file name to hide.
       */
      @Override public boolean hideGpx(net.osmand.aidlapi.gpx.HideGpxParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_hideGpx, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Get list of active GPX files.
       * 
       * @return list of active gpx files.
       */
      @Override public boolean getActiveGpx(java.util.List<net.osmand.aidlapi.gpx.ASelectedGpxFile> files) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getActiveGpx, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
          _reply.readTypedList(files, net.osmand.aidlapi.gpx.ASelectedGpxFile.CREATOR);
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Set map view to current location.
       * 
       * @param latitude (double) - latitude of new map center.
       * @param longitude (double) - longitude of new map center.
       * @param zoom (float) - map zoom level. Set 0 to keep zoom unchanged.
       * @param animated (boolean) - set true to animate changes.
       */
      @Override public boolean setMapLocation(net.osmand.aidlapi.map.SetMapLocationParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_setMapLocation, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean calculateRoute(net.osmand.aidlapi.calculateroute.CalculateRouteParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_calculateRoute, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /** Refresh the map (UI) */
      @Override public boolean refreshMap() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_refreshMap, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Add favorite group with given params.
       * 
       * @param name (String)    - group name.
       * @param color (String)  - group color. Can be one of: "red", "orange", "yellow",
       *                "lightgreen", "green", "lightblue", "blue", "purple", "pink", "brown".
       * @param visible (boolean) - group visibility.
       */
      @Override public boolean addFavoriteGroup(net.osmand.aidlapi.favorite.group.AddFavoriteGroupParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_addFavoriteGroup, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Remove favorite group with given name.
       * 
       * @param name (String) - name of favorite group.
       */
      @Override public boolean removeFavoriteGroup(net.osmand.aidlapi.favorite.group.RemoveFavoriteGroupParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_removeFavoriteGroup, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Update favorite group with given params.
       * 
       * @param namePrev (String) - group name (current).
       * @param colorPrev (String) - group color (current).
       * @param visiblePrev (boolean) - group visibility (current).
       * @param nameNew (String)  - group name (new).
       * @param colorNew (String)  - group color (new).
       * @param visibleNew (boolean) - group visibility (new).
       */
      @Override public boolean updateFavoriteGroup(net.osmand.aidlapi.favorite.group.UpdateFavoriteGroupParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_updateFavoriteGroup, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Add favorite at given location with given params.
       * 
       * @param lat (double) - latitude.
       * @param lon (double)  - longitude.
       * @param name (String)  - name of favorite item.
       * @param description (String)  - description of favorite item.
       * @param category (String)  - category of favorite item.
       * @param color (String)  - color of favorite item. Can be one of: "red", "orange", "yellow",
       *                    "lightgreen", "green", "lightblue", "blue", "purple", "pink", "brown".
       * @param visible (boolean) - should favorite item be visible after creation.
       */
      @Override public boolean addFavorite(net.osmand.aidlapi.favorite.AddFavoriteParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_addFavorite, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Remove favorite at given location with given params.
       * 
       * @param lat (double)  - latitude.
       * @param lon (double) - longitude.
       * @param name (String) - name of favorite item.
       * @param category (String) - category of favorite item.
       */
      @Override public boolean removeFavorite(net.osmand.aidlapi.favorite.RemoveFavoriteParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_removeFavorite, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Update favorite at given location with given params.
       * 
       * @param latPrev (double)  - latitude (current favorite).
       * @param lonPrev (double) - longitude (current favorite).
       * @param namePrev (String) - name of favorite item (current favorite).
       * @param categoryPrev (String) - category of favorite item (current favorite).
       * @param latNew (double)  - latitude (new favorite).
       * @param lonNew (double)  - longitude (new favorite).
       * @param nameNew (String)  - name of favorite item (new favorite).
       * @param descriptionNew (String) - description of favorite item (new favorite).
       * @param categoryNew (String) - category of favorite item (new favorite). Use only to create a new category,
       *                       not to update an existing one. If you want to  update an existing category,
       *                       use the {@link #updateFavoriteGroup(String, String, boolean, String, String, boolean)} method.
       * @param colorNew (String) - color of new category. Can be one of: "red", "orange", "yellow",
       *                       "lightgreen", "green", "lightblue", "blue", "purple", "pink", "brown".
       * @param visibleNew (boolean) - should new category be visible after creation.
       */
      @Override public boolean updateFavorite(net.osmand.aidlapi.favorite.UpdateFavoriteParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_updateFavorite, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /** Start gpx recording. */
      @Override public boolean startGpxRecording(net.osmand.aidlapi.gpx.StartGpxRecordingParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_startGpxRecording, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /** Stop gpx recording. */
      @Override public boolean stopGpxRecording(net.osmand.aidlapi.gpx.StopGpxRecordingParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_stopGpxRecording, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Take photo note.
       * 
       * @param lat (double) - latutude of photo note.
       * @param lon (double) - longitude of photo note.
       */
      @Override public boolean takePhotoNote(net.osmand.aidlapi.note.TakePhotoNoteParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_takePhotoNote, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Start video note recording.
       * 
       * @param lat (double) - latutude of video note point.
       * @param lon (double) - longitude of video note point.
       */
      @Override public boolean startVideoRecording(net.osmand.aidlapi.note.StartVideoRecordingParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_startVideoRecording, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Start audio note recording.
       * 
       * @param lat (double) - latutude of audio note point.
       * @param lon (double) - longitude of audio note point.
       */
      @Override public boolean startAudioRecording(net.osmand.aidlapi.note.StartAudioRecordingParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_startAudioRecording, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /** Stop Audio/Video recording. */
      @Override public boolean stopRecording(net.osmand.aidlapi.note.StopRecordingParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_stopRecording, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Start navigation.
       * 
       * @param startName (String) - name of the start point as it displays in OsmAnd's UI. Nullable.
       * @param startLat (double) - latitude of the start point. If 0 - current location is used.
       * @param startLon (double) - longitude of the start point. If 0 - current location is used.
       * @param destName (String) - name of the start point as it displays in OsmAnd's UI.
       * @param destLat (double) - latitude of a destination point.
       * @param destLon (double) - longitude of a destination point.
       * @param profile (String)  - One of: "default", "car", "bicycle", "pedestrian", "aircraft", "boat", "hiking", "motorcycle", "truck". Nullable (default).
       * @param force (boolean) - ask to stop current navigation if any. False - ask. True - don't ask.
       */
      @Override public boolean navigate(net.osmand.aidlapi.navigation.NavigateParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_navigate, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Start navigation using gpx file. User need to grant Uri permission to OsmAnd.
       * 
       * @param gpxUri (Uri) - URI created by FileProvider.
       * @param force (boolean) - ask to stop current navigation if any. False - ask. True - don't ask.
       */
      @Override public boolean navigateGpx(net.osmand.aidlapi.navigation.NavigateGpxParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_navigateGpx, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
          if ((0!=_reply.readInt())) {
            params.readFromParcel(_reply);
          }
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Remove GPX file.
       * 
       * @param fileName (String) - file name to remove;
       */
      @Override public boolean removeGpx(net.osmand.aidlapi.gpx.RemoveGpxParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_removeGpx, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Show AMapPoint on map in OsmAnd.
       * 
       * @param layerId (String) - layer id. Note: layer should be added first.
       * @param pointId (String) - point id.
       * @param shortName (String) - short name (single char). Displayed on the map.
       * @param fullName (String) - full name. Displayed in the context menu on first row.
       * @param typeName (String) - type name. Displayed in context menu on second row.
       * @param color (int) - color of circle's background.
       * @param location (ALatLon) - location of the point.
       * @param details List<String> - list of details. Displayed under context menu.
       * @param params Map<String, String> - optional map of params for point.
       */
      @Override public boolean showMapPoint(net.osmand.aidlapi.maplayer.point.ShowMapPointParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_showMapPoint, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Method for adding up to 3 items to the OsmAnd navigation drawer.
       * 
       * @param appPackage - current application package.
       * @param names - list of names for items.
       * @param uris - list of uris for intents.
       * @param iconNames - list of icon names for items.
       * @param flags - list of flags for intents. Use -1 if no flags needed.
       */
      @Override public boolean setNavDrawerItems(net.osmand.aidlapi.navdrawer.SetNavDrawerItemsParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_setNavDrawerItems, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /** Put navigation on pause. */
      @Override public boolean pauseNavigation(net.osmand.aidlapi.navigation.PauseNavigationParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_pauseNavigation, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /** Resume navigation if it was paused before. */
      @Override public boolean resumeNavigation(net.osmand.aidlapi.navigation.ResumeNavigationParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_resumeNavigation, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /** Stop navigation. Removes target / intermediate points and route path from the map. */
      @Override public boolean stopNavigation(net.osmand.aidlapi.navigation.StopNavigationParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_stopNavigation, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /** Mute voice guidance. Stays muted until unmute manually or via the api. */
      @Override public boolean muteNavigation(net.osmand.aidlapi.navigation.MuteNavigationParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_muteNavigation, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /** Unmute voice guidance. */
      @Override public boolean unmuteNavigation(net.osmand.aidlapi.navigation.UnmuteNavigationParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_unmuteNavigation, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Run search for POI / Address.
       * 
       * @param searchQuery (String) - search query string.
       * @param searchType (int) - type of search. Values:
       *                   SearchParams.SEARCH_TYPE_ALL - all kind of search
       *                   SearchParams.SEARCH_TYPE_POI - POIs only
       *                   SearchParams.SEARCH_TYPE_ADDRESS - addresses only
       * 
       * @param latitude (double) - latitude of original search location.
       * @param longitude (double) - longitude of original search location.
       * @param radiusLevel (int) - value from 1 to 7. Default value = 1.
       * @param totalLimit (int) - limit of returned search result rows. Default value = -1 (unlimited).
       */
      @Override public boolean search(net.osmand.aidlapi.search.SearchParams params, net.osmand.aidlapi.IOsmAndAidlCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_search, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Do search and start navigation.
       * 
       * @param startName (String) - name of the start point as it displays in OsmAnd's UI. Nullable.
       * @param startLat (double) - latitude of the start point. If 0 - current location is used.
       * @param startLon (double) - longitude of the start point. If 0 - current location is used.
       * @param searchQuery (String) - Text of a query for searching a destination point. Sent as URI parameter.
       * @param searchLat (double) - original location of search (latitude). Sent as URI parameter.
       * @param searchLon (double) - original location of search (longitude). Sent as URI parameter.
       * @param profile (String) - one of: "default", "car", "bicycle", "pedestrian", "aircraft", "boat", "hiking", "motorcycle", "truck". Nullable (default).
       * @param force (boolean) - ask to stop current navigation if any. False - ask. True - don't ask.
       */
      @Override public boolean navigateSearch(net.osmand.aidlapi.navigation.NavigateSearchParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_navigateSearch, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Method to register for periodical callbacks from OsmAnd
       * 
       * @param updateTimeMS (long)- period of time in millisecond after which callback is triggered
       * @param callback (IOsmAndCallback)- create and provide instance of {@link IOsmAndAidlCallback} interface
       * @return id (long) - id of callback in OsmAnd. Needed to unsubscribe from updates.
       */
      @Override public long registerForUpdates(long updateTimeMS, net.osmand.aidlapi.IOsmAndAidlCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        long _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeLong(updateTimeMS);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_registerForUpdates, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readLong();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Method to unregister from periodical callbacks from OsmAnd
       * 
       * @param callbackId (long)- id of registered callback (provided by OsmAnd
       * in {@link OsmAndAidlHelper#registerForUpdates(long, IOsmAndAidlCallback)})
       */
      @Override public boolean unregisterFromUpdates(long callbackId) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeLong(callbackId);
          boolean _status = mRemote.transact(Stub.TRANSACTION_unregisterFromUpdates, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Method for adding image to the top of Osmand's NavDrawer.
       * 
       * @param imageUri (String)- image's URI.toString
       * 
       * @deprecated
       * Use the {@link #setNavDrawerLogoWithParams(NavDrawerHeaderParams params)} method.
       */
      @Override public boolean setNavDrawerLogo(java.lang.String imageUri) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(imageUri);
          boolean _status = mRemote.transact(Stub.TRANSACTION_setNavDrawerLogo, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Method for selected UI elements (like QuickSearch button) to show.
       * 
       * @param ids (List<String>)- list of menu items keys from {@link OsmAndCustomizationConstants}
       */
      @Override public boolean setEnabledIds(java.util.List<java.lang.String> ids) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStringList(ids);
          boolean _status = mRemote.transact(Stub.TRANSACTION_setEnabledIds, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Method for selected UI elements (like QuickSearch button) to hide.
       * 
       * @param ids (List<String>)- list of menu items keys from {@link OsmAndCustomizationConstants}
       */
      @Override public boolean setDisabledIds(java.util.List<java.lang.String> ids) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStringList(ids);
          boolean _status = mRemote.transact(Stub.TRANSACTION_setDisabledIds, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Method to show selected NavDrawer's menu items.
       * 
       * @param patterns (List<String>) - list of menu items names from {@link OsmAndCustomizationConstants}
       */
      @Override public boolean setEnabledPatterns(java.util.List<java.lang.String> patterns) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStringList(patterns);
          boolean _status = mRemote.transact(Stub.TRANSACTION_setEnabledPatterns, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Method to hide selected NavDrawer's menu items.
       * 
       * @param patterns (List<String>)- list of menu items names from {@link OsmAndCustomizationConstants}
       */
      @Override public boolean setDisabledPatterns(java.util.List<java.lang.String> patterns) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStringList(patterns);
          boolean _status = mRemote.transact(Stub.TRANSACTION_setDisabledPatterns, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Register OsmAnd widgets for visibility.
       * 
       * @param widgetKey ()- widget id.
       * @param appModKeys - list of OsmAnd Application modes widget active with. Could be "null" for all modes.
       */
      @Override public boolean regWidgetVisibility(net.osmand.aidlapi.customization.SetWidgetsParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_regWidgetVisibility, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Register OsmAnd widgets for availability.
       * 
       * @param widgetKey (String) - widget id.
       * @param appModKeys (List<String>)- ist of OsmAnd Application modes widget active with. Could be "null" for all modes.
       */
      @Override public boolean regWidgetAvailability(net.osmand.aidlapi.customization.SetWidgetsParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_regWidgetAvailability, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Add custom parameters for OsmAnd settings to associate with client app.
       * 
       * @param sharedPreferencesName (String)- string with name of clint's app for shared preferences key
       * @param bundle (Bundle)- bundle with keys from Settings IDs {@link OsmAndCustomizationConstants} and Settings params
       */
      @Override public boolean customizeOsmandSettings(net.osmand.aidlapi.customization.OsmandSettingsParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_customizeOsmandSettings, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Method to get list of gpx files currently registered (imported or created) in OsmAnd;
       * 
       * @return list of gpx files
       */
      @Override public boolean getImportedGpx(java.util.List<net.osmand.aidlapi.gpx.AGpxFile> files) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getImportedGpx, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
          _reply.readTypedList(files, net.osmand.aidlapi.gpx.AGpxFile.CREATOR);
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Method to get list of sqlitedb files registered in OsmAnd;
       * 
       * @return list of sqlitedb files
       */
      @Override public boolean getSqliteDbFiles(java.util.List<net.osmand.aidlapi.tiles.ASqliteDbFile> files) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getSqliteDbFiles, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
          _reply.readTypedList(files, net.osmand.aidlapi.tiles.ASqliteDbFile.CREATOR);
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Method to get list of currently active sqlitedb files
       * 
       * @return list of sqlitedb files
       */
      @Override public boolean getActiveSqliteDbFiles(java.util.List<net.osmand.aidlapi.tiles.ASqliteDbFile> files) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getActiveSqliteDbFiles, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
          _reply.readTypedList(files, net.osmand.aidlapi.tiles.ASqliteDbFile.CREATOR);
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Method to show selected sqlitedb file as map overlay.
       * 
       * @param fileName (String) - name of sqlitedb file
       */
      @Override public boolean showSqliteDbFile(java.lang.String fileName) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(fileName);
          boolean _status = mRemote.transact(Stub.TRANSACTION_showSqliteDbFile, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Method to hide sqlitedb file from map overlay.
       * 
       * @param fileName (String) - name of sqlitedb file
       */
      @Override public boolean hideSqliteDbFile(java.lang.String fileName) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(fileName);
          boolean _status = mRemote.transact(Stub.TRANSACTION_hideSqliteDbFile, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Method for adding image to the top of OsmAnd's NavDrawer with additional params
       * 
       * @param imageUri (String) - image's URI.toString
       * @param packageName (String) - client's app package name
       * @param intent (String) - intent for additional functionality on image click
       */
      @Override public boolean setNavDrawerLogoWithParams(net.osmand.aidlapi.navdrawer.NavDrawerHeaderParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_setNavDrawerLogoWithParams, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Method for adding functionality to "Powered by Osmand" logo in NavDrawer's footer
       * (reset OsmAnd settings to pre-clinet app's state)
       * 
       * @param packageName (String) - package name
       * @param intent (String) - intent
       * @param appName (String) - client's app name
       */
      @Override public boolean setNavDrawerFooterWithParams(net.osmand.aidlapi.navdrawer.NavDrawerFooterParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_setNavDrawerFooterWithParams, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Restore default (pre-client) OsmAnd settings and state:
       * clears features, widgets and settings customization, NavDraw logo.
       */
      @Override public boolean restoreOsmand() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_restoreOsmand, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Method to change state of plug-ins in OsmAnd.
       * 
       * @param pluginId (String) - id (name) of plugin.
       * @param newState (int) - new state (0 - off, 1 - on).
       */
      @Override public boolean changePluginState(net.osmand.aidlapi.plugins.PluginParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_changePluginState, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Method to register for callback on OsmAnd initialization
       * @param callback (IOsmAndAidlCallback) - create and provide instance of {@link IOsmAndAidlCallback} interface
       */
      @Override public boolean registerForOsmandInitListener(net.osmand.aidlapi.IOsmAndAidlCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_registerForOsmandInitListener, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Requests bitmap snap-shot of map with GPX file from provided URI in its center.
       * You can set bitmap size, density and GPX lines color, but you need
       * to manually download appropriate map in OsmAnd or background will be empty.
       * Bitmap will be returned through callback {@link IOsmAndAidlCallback#onGpxBitmapCreated(AGpxBitmap)}
       * 
       * @param gpxUri (Uri/File) - Uri for gpx file
       * @param density (float) - image density. Recommended to use default metrics for device's display.
       * @param widthPixels (int) - width of bitmap
       * @param heightPixels (int) - height of bitmap
       * @param color (int) - color in ARGB format
       * @param callback (IOsmAndAidlCallback) - instance of callback from OsmAnd.
       */
      @Override public boolean getBitmapForGpx(net.osmand.aidlapi.gpx.CreateGpxBitmapParams file, net.osmand.aidlapi.IOsmAndAidlCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, file, 0);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getBitmapForGpx, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Method to copy files to OsmAnd part by part. For now supports only sqlitedb format.
       * Part size (bytearray) should not exceed 256k.
       * 
       * @param fileName (String) - name of file
       * @param filePartData (byte[]) - parts of file, byte[] with size 256k or less.
       * @param startTime (long) - timestamp of copying start.
       * @param isDone (boolean) - boolean to mark end of copying.
       * @return number of last successfully received file part or error(-1).
       */
      @Override public int copyFile(net.osmand.aidlapi.copyfile.CopyFileParams filePart) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        int _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, filePart, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_copyFile, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readInt();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Method to register for updates during navgation. Notifies user about distance to the next turn and its type.
       * 
       * @param subscribeToUpdates (boolean) - subscribe or unsubscribe from updates
       * @param callbackId (long) - id of callback, needed to unsubscribe from updates
       * @param callback (IOsmAndAidlCallback) - callback to notify user on navigation data change
       */
      @Override public long registerForNavigationUpdates(net.osmand.aidlapi.navigation.ANavigationUpdateParams params, net.osmand.aidlapi.IOsmAndAidlCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        long _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_registerForNavigationUpdates, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readLong();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Method to add Context Menu buttons to OsmAnd Context menu.
       * 
       * {@link ContextMenuButtonsParams } is a wrapper class for params:
       * 
       * @param leftButton (AContextMenuButton) - parameters for left context button:
       * @param buttonId (String at AContextMenuButton) - id of button in View
       * @param leftTextCaption (String at AContextMenuButton) - left-side button text
       * @param rightTextCaption (String at AContextMenuButton) - right-side button text
       * @param String leftIconName (String at AContextMenuButton) - name of left-side icon
       * @param String rightIconName (String at AContextMenuButton) - name of right-side icon
       * @param boolean needColorizeIcon (booleanat AContextMenuButton) - flag to apply color to icon
       * @param boolean enabled (boolean at AContextMenuButton) - enable button flag
       * 
       * @param rightButton (AContextMenuButton) - parameters for right context button, see <i>leftButton</i> param for details.
       * @param id (String) - button id;
       * @param appPackage (String) - clinet's app package name
       * @param layerId (String) - id of Osmand's map layer
       * @param callbackId (long) - {@link IOsmAndAidlCallback} id
       * @param pointsIds (List<String>) - list of point Ids to which this rules applies to.
       * 
       * @param callback (IOsmAndAidlCallback) - AIDL callback;
       * 
       * @return long - callback's Id;
       */
      @Override public long addContextMenuButtons(net.osmand.aidlapi.contextmenu.ContextMenuButtonsParams params, net.osmand.aidlapi.IOsmAndAidlCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        long _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_addContextMenuButtons, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readLong();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Method to remove Context Menu buttons from OsmAnd Context menu.
       * 
       * {@link RemoveContextMenuButtonsParams} is a wrapper class for params:
       * 
       * @param paramsId (String) - id of {@link ContextMenuButtonsParams} of button you want to remove;
       * @param callbackId (long) - id of {@ling IOsmAndAidlCallback} of button you want to remove;
       */
      @Override public boolean removeContextMenuButtons(net.osmand.aidlapi.contextmenu.RemoveContextMenuButtonsParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_removeContextMenuButtons, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Method to update params on already set custom Context Button.
       * 
       * {@link UpdateContextMenuButtonsParams } is a wrapper class for params:
       * 
       * @param leftButton (AContextMenuButton) - parameters for left context button:
       * @param buttonId (String at AContextMenuButton) - id of button in View
       * @param leftTextCaption (String at AContextMenuButton) - left-side button text
       * @param rightTextCaption (String at AContextMenuButton) - right-side button text
       * @param String leftIconName (String at AContextMenuButton) - name of left-side icon
       * @param String rightIconName (String at AContextMenuButton) - name of right-side icon
       * @param boolean needColorizeIcon (booleanat AContextMenuButton) - flag to apply color to icon
       * @param boolean enabled (boolean at AContextMenuButton) - enable button flag
       * 
       * @param rightButton (AContextMenuButton) - parameters for right context button, see <i>leftButton</i> param for details.
       * @param id (String) - button id;
       * @param appPackage (String) - clinet's app package name
       * @param layerId (String) - id of Osmand's map layer
       * @param callbackId (long) - {@link IOsmAndAidlCallback} id
       * @param pointsIds (List<String>) - list of point Ids to which this rules applies to.
       */
      @Override public boolean updateContextMenuButtons(net.osmand.aidlapi.contextmenu.UpdateContextMenuButtonsParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_updateContextMenuButtons, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Method to check if there is a customized setting in OsmAnd Settings.
       * 
       * {@link OsmandSettingsInfoParams} is a wrapper class for params:
       * 
       * @param sharedPreferencesName (String at OsmandSettingInfoParams) - key of setting in OsmAnd's preferences.
       * 
       * @return boolean - true if setting is already set in SharedPreferences
       */
      @Override public boolean areOsmandSettingsCustomized(net.osmand.aidlapi.customization.OsmandSettingsInfoParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_areOsmandSettingsCustomized, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Method to customize parameters of OsmAnd.
       * 
       * @param params (CustomizationInfoParams) - wrapper class for custom settings and ui.
       * 
       * @param settingsParams (OsmandSettingsParams) - wrapper class for OsmAnd shared preferences params.
       * 			   See {@link #customizeOsmandSettings(in OsmandSettingsParams params) customizeOsmandSettings}
       * 			   method description for details.
       * @param navDrawerHeaderParams (NavDrawerHeaderParams) - wrapper class for OsmAnd navdrawer header params.
       * 			   See {@link #setNavDrawerLogoWithParams(in NavDrawerHeaderParams params) setNavDrawerLogoWithParams}
       * 			   method description for details.
       * @param navDrawerFooterParams (NavDrawerFooterParams) - wrapper class for OsmAnd navdrawer footer params.
       * 			   See {@link #setNavDrawerFooterWithParams(in NavDrawerFooterParams params) setNavDrawerFooterWithParams}
       * 			   method description for details.
       * @param visibilityWidgetsParams (ArrayList<SetWidgetsParams>) - wrapper class for OsmAnd widgets visibility.
       * 			   See {@link #regWidgetVisibility(in SetWidgetsParams params) regWidgetVisibility}
       * 			   method description for details.
       * @param availabilityWidgetsParams (ArrayList<SetWidgetsParams>) - wrapper class for OsmAnd widgets availability.
       * 			   See {@link #regWidgetAvailability(in SetWidgetsParams params) regWidgetAvailability}
       * 			   method description for details.
       * @param pluginsParams (ArrayList<PluginParams>) - wrapper class for OsmAnd plugins states params.
       * 			   See {@link #changePluginState(in PluginParams params) changePluginState}
       * 			   method description for details.
       * @param featuresEnabledIds (List<String>) - list of UI elements (like QuickSearch button) to show.
       * 			   See {@link #setEnabledIds(in List<String> ids) setEnabledIds}
       * @param featuresDisabledIds (List<String>) - list of UI elements (like QuickSearch button) to hide.
       * 			   See {@link #setDisabledIds(in List<String> ids) setDisabledIds}
       * @param featuresEnabledPatterns (List<String>) - list of NavDrawer menu items to show.
       * 			   See {@link #setEnabledPatterns(in List<String> patterns) setEnabledPatterns}
       * @param featuresDisabledPatterns (List<String>) - list of NavDrawer menu items to hide.
       * 			   See {@link #setDisabledPatterns(in List<String> patterns) setDisabledPatterns}
       */
      @Override public boolean setCustomization(net.osmand.aidlapi.customization.CustomizationInfoParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_setCustomization, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Method to register for Voice Router voice messages during navigation. Notifies user about voice messages.
       * 
       * @params subscribeToUpdates (boolean) - boolean flag to subscribe or unsubscribe from messages
       * @params callbackId (long) - id of callback, needed to unsubscribe from messages
       * @params callback (IOsmAndAidlCallback) - callback to notify user on voice message
       */
      @Override public long registerForVoiceRouterMessages(net.osmand.aidlapi.navigation.ANavigationVoiceRouterMessageParams params, net.osmand.aidlapi.IOsmAndAidlCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        long _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_registerForVoiceRouterMessages, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readLong();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Removes all active map markers (marks them as passed and moves to history)
       * Empty class of params
       */
      @Override public boolean removeAllActiveMapMarkers(net.osmand.aidlapi.mapmarker.RemoveMapMarkersParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_removeAllActiveMapMarkers, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean importProfile(net.osmand.aidlapi.customization.ProfileSettingsParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_importProfile, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean executeQuickAction(net.osmand.aidlapi.quickaction.QuickActionParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_executeQuickAction, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean getQuickActionsInfo(java.util.List<net.osmand.aidlapi.quickaction.QuickActionInfoParams> quickActions) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getQuickActionsInfo, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
          _reply.readTypedList(quickActions, net.osmand.aidlapi.quickaction.QuickActionInfoParams.CREATOR);
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /** Toggle Lock/Unlock screen. */
      @Override public boolean setLockState(net.osmand.aidlapi.lock.SetLockStateParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_setLockState, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Method to register for  key events.
       * 
       * @params subscribeToUpdates (boolean) - boolean flag to subscribe or unsubscribe from key events
       * @params callbackId (long) - id of callback, needed to unsubscribe key events
       * @params callback (IOsmAndAidlCallback) - callback to notify user on key event
       * @params keyEventList (List<Integer>) - list of requested key events
       */
      @Override public long registerForKeyEvents(net.osmand.aidlapi.events.AKeyEventsParams params, net.osmand.aidlapi.IOsmAndAidlCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        long _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_registerForKeyEvents, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readLong();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public net.osmand.aidlapi.info.AppInfoParams getAppInfo() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        net.osmand.aidlapi.info.AppInfoParams _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getAppInfo, _data, _reply, 0);
          _reply.readException();
          _result = _Parcel.readTypedObject(_reply, net.osmand.aidlapi.info.AppInfoParams.CREATOR);
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean setMapMargins(net.osmand.aidlapi.customization.MapMarginsParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_setMapMargins, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean exportProfile(net.osmand.aidlapi.profile.ExportProfileParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_exportProfile, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /** Is any fragment open. */
      @Override public boolean isFragmentOpen() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_isFragmentOpen, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /** Is contect menu open. */
      @Override public boolean isMenuOpen() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_isMenuOpen, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public int getPluginVersion(net.osmand.aidlapi.customization.CustomPluginParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        int _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getPluginVersion, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readInt();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean selectProfile(net.osmand.aidlapi.customization.SelectProfileParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_selectProfile, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean getProfiles(java.util.List<net.osmand.aidlapi.customization.AProfile> profiles) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getProfiles, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
          _reply.readTypedList(profiles, net.osmand.aidlapi.customization.AProfile.CREATOR);
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean getBlockedRoads(java.util.List<net.osmand.aidlapi.navigation.ABlockedRoad> blockedRoads) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getBlockedRoads, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
          _reply.readTypedList(blockedRoads, net.osmand.aidlapi.navigation.ABlockedRoad.CREATOR);
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean addRoadBlock(net.osmand.aidlapi.navigation.AddBlockedRoadParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_addRoadBlock, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean removeRoadBlock(net.osmand.aidlapi.navigation.RemoveBlockedRoadParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_removeRoadBlock, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean setLocation(net.osmand.aidlapi.map.SetLocationParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_setLocation, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean exitApp(net.osmand.aidlapi.exit.ExitAppParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_exitApp, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean getText(net.osmand.aidlapi.info.GetTextParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getText, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
          if ((0!=_reply.readInt())) {
            params.readFromParcel(_reply);
          }
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean reloadIndexes() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_reloadIndexes, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean setPreference(net.osmand.aidlapi.customization.PreferenceParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_setPreference, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean getPreference(net.osmand.aidlapi.customization.PreferenceParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getPreference, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
          if ((0!=_reply.readInt())) {
            params.readFromParcel(_reply);
          }
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Method to register for Logcat messages. Notifies user about new logs in application.
       * 
       * @param subscribeToUpdates (boolean) - boolean flag to subscribe or unsubscribe from messages
       * @param callbackId (long) - id of callback, needed to unsubscribe from messages
       * @param filterLevel (String) determines which type of logs will be returned by callback
       * Must be one of the values below:
       * - "D" (debug)
       * - "I" (info)
       * - "W" (warn)
       * - "E" (error)
       * @param callback (IOsmAndAidlCallback) - callback to notify user on new OsmAnd logs
       */
      @Override public long registerForLogcatMessages(net.osmand.aidlapi.logcat.ALogcatListenerParams params, net.osmand.aidlapi.IOsmAndAidlCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        long _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_registerForLogcatMessages, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readLong();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public boolean setZoomLimits(net.osmand.aidlapi.customization.ZoomLimitsParams params) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, params, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_setZoomLimits, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
    }
    static final int TRANSACTION_addMapMarker = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
    static final int TRANSACTION_removeMapMarker = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
    static final int TRANSACTION_updateMapMarker = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
    static final int TRANSACTION_addMapWidget = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
    static final int TRANSACTION_removeMapWidget = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
    static final int TRANSACTION_updateMapWidget = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
    static final int TRANSACTION_addMapPoint = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
    static final int TRANSACTION_removeMapPoint = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
    static final int TRANSACTION_updateMapPoint = (android.os.IBinder.FIRST_CALL_TRANSACTION + 8);
    static final int TRANSACTION_addMapLayer = (android.os.IBinder.FIRST_CALL_TRANSACTION + 9);
    static final int TRANSACTION_removeMapLayer = (android.os.IBinder.FIRST_CALL_TRANSACTION + 10);
    static final int TRANSACTION_updateMapLayer = (android.os.IBinder.FIRST_CALL_TRANSACTION + 11);
    static final int TRANSACTION_importGpx = (android.os.IBinder.FIRST_CALL_TRANSACTION + 12);
    static final int TRANSACTION_showGpx = (android.os.IBinder.FIRST_CALL_TRANSACTION + 13);
    static final int TRANSACTION_hideGpx = (android.os.IBinder.FIRST_CALL_TRANSACTION + 14);
    static final int TRANSACTION_getActiveGpx = (android.os.IBinder.FIRST_CALL_TRANSACTION + 15);
    static final int TRANSACTION_setMapLocation = (android.os.IBinder.FIRST_CALL_TRANSACTION + 16);
    static final int TRANSACTION_calculateRoute = (android.os.IBinder.FIRST_CALL_TRANSACTION + 17);
    static final int TRANSACTION_refreshMap = (android.os.IBinder.FIRST_CALL_TRANSACTION + 18);
    static final int TRANSACTION_addFavoriteGroup = (android.os.IBinder.FIRST_CALL_TRANSACTION + 19);
    static final int TRANSACTION_removeFavoriteGroup = (android.os.IBinder.FIRST_CALL_TRANSACTION + 20);
    static final int TRANSACTION_updateFavoriteGroup = (android.os.IBinder.FIRST_CALL_TRANSACTION + 21);
    static final int TRANSACTION_addFavorite = (android.os.IBinder.FIRST_CALL_TRANSACTION + 22);
    static final int TRANSACTION_removeFavorite = (android.os.IBinder.FIRST_CALL_TRANSACTION + 23);
    static final int TRANSACTION_updateFavorite = (android.os.IBinder.FIRST_CALL_TRANSACTION + 24);
    static final int TRANSACTION_startGpxRecording = (android.os.IBinder.FIRST_CALL_TRANSACTION + 25);
    static final int TRANSACTION_stopGpxRecording = (android.os.IBinder.FIRST_CALL_TRANSACTION + 26);
    static final int TRANSACTION_takePhotoNote = (android.os.IBinder.FIRST_CALL_TRANSACTION + 27);
    static final int TRANSACTION_startVideoRecording = (android.os.IBinder.FIRST_CALL_TRANSACTION + 28);
    static final int TRANSACTION_startAudioRecording = (android.os.IBinder.FIRST_CALL_TRANSACTION + 29);
    static final int TRANSACTION_stopRecording = (android.os.IBinder.FIRST_CALL_TRANSACTION + 30);
    static final int TRANSACTION_navigate = (android.os.IBinder.FIRST_CALL_TRANSACTION + 31);
    static final int TRANSACTION_navigateGpx = (android.os.IBinder.FIRST_CALL_TRANSACTION + 32);
    static final int TRANSACTION_removeGpx = (android.os.IBinder.FIRST_CALL_TRANSACTION + 33);
    static final int TRANSACTION_showMapPoint = (android.os.IBinder.FIRST_CALL_TRANSACTION + 34);
    static final int TRANSACTION_setNavDrawerItems = (android.os.IBinder.FIRST_CALL_TRANSACTION + 35);
    static final int TRANSACTION_pauseNavigation = (android.os.IBinder.FIRST_CALL_TRANSACTION + 36);
    static final int TRANSACTION_resumeNavigation = (android.os.IBinder.FIRST_CALL_TRANSACTION + 37);
    static final int TRANSACTION_stopNavigation = (android.os.IBinder.FIRST_CALL_TRANSACTION + 38);
    static final int TRANSACTION_muteNavigation = (android.os.IBinder.FIRST_CALL_TRANSACTION + 39);
    static final int TRANSACTION_unmuteNavigation = (android.os.IBinder.FIRST_CALL_TRANSACTION + 40);
    static final int TRANSACTION_search = (android.os.IBinder.FIRST_CALL_TRANSACTION + 41);
    static final int TRANSACTION_navigateSearch = (android.os.IBinder.FIRST_CALL_TRANSACTION + 42);
    static final int TRANSACTION_registerForUpdates = (android.os.IBinder.FIRST_CALL_TRANSACTION + 43);
    static final int TRANSACTION_unregisterFromUpdates = (android.os.IBinder.FIRST_CALL_TRANSACTION + 44);
    static final int TRANSACTION_setNavDrawerLogo = (android.os.IBinder.FIRST_CALL_TRANSACTION + 45);
    static final int TRANSACTION_setEnabledIds = (android.os.IBinder.FIRST_CALL_TRANSACTION + 46);
    static final int TRANSACTION_setDisabledIds = (android.os.IBinder.FIRST_CALL_TRANSACTION + 47);
    static final int TRANSACTION_setEnabledPatterns = (android.os.IBinder.FIRST_CALL_TRANSACTION + 48);
    static final int TRANSACTION_setDisabledPatterns = (android.os.IBinder.FIRST_CALL_TRANSACTION + 49);
    static final int TRANSACTION_regWidgetVisibility = (android.os.IBinder.FIRST_CALL_TRANSACTION + 50);
    static final int TRANSACTION_regWidgetAvailability = (android.os.IBinder.FIRST_CALL_TRANSACTION + 51);
    static final int TRANSACTION_customizeOsmandSettings = (android.os.IBinder.FIRST_CALL_TRANSACTION + 52);
    static final int TRANSACTION_getImportedGpx = (android.os.IBinder.FIRST_CALL_TRANSACTION + 53);
    static final int TRANSACTION_getSqliteDbFiles = (android.os.IBinder.FIRST_CALL_TRANSACTION + 54);
    static final int TRANSACTION_getActiveSqliteDbFiles = (android.os.IBinder.FIRST_CALL_TRANSACTION + 55);
    static final int TRANSACTION_showSqliteDbFile = (android.os.IBinder.FIRST_CALL_TRANSACTION + 56);
    static final int TRANSACTION_hideSqliteDbFile = (android.os.IBinder.FIRST_CALL_TRANSACTION + 57);
    static final int TRANSACTION_setNavDrawerLogoWithParams = (android.os.IBinder.FIRST_CALL_TRANSACTION + 58);
    static final int TRANSACTION_setNavDrawerFooterWithParams = (android.os.IBinder.FIRST_CALL_TRANSACTION + 59);
    static final int TRANSACTION_restoreOsmand = (android.os.IBinder.FIRST_CALL_TRANSACTION + 60);
    static final int TRANSACTION_changePluginState = (android.os.IBinder.FIRST_CALL_TRANSACTION + 61);
    static final int TRANSACTION_registerForOsmandInitListener = (android.os.IBinder.FIRST_CALL_TRANSACTION + 62);
    static final int TRANSACTION_getBitmapForGpx = (android.os.IBinder.FIRST_CALL_TRANSACTION + 63);
    static final int TRANSACTION_copyFile = (android.os.IBinder.FIRST_CALL_TRANSACTION + 64);
    static final int TRANSACTION_registerForNavigationUpdates = (android.os.IBinder.FIRST_CALL_TRANSACTION + 65);
    static final int TRANSACTION_addContextMenuButtons = (android.os.IBinder.FIRST_CALL_TRANSACTION + 66);
    static final int TRANSACTION_removeContextMenuButtons = (android.os.IBinder.FIRST_CALL_TRANSACTION + 67);
    static final int TRANSACTION_updateContextMenuButtons = (android.os.IBinder.FIRST_CALL_TRANSACTION + 68);
    static final int TRANSACTION_areOsmandSettingsCustomized = (android.os.IBinder.FIRST_CALL_TRANSACTION + 69);
    static final int TRANSACTION_setCustomization = (android.os.IBinder.FIRST_CALL_TRANSACTION + 70);
    static final int TRANSACTION_registerForVoiceRouterMessages = (android.os.IBinder.FIRST_CALL_TRANSACTION + 71);
    static final int TRANSACTION_removeAllActiveMapMarkers = (android.os.IBinder.FIRST_CALL_TRANSACTION + 72);
    static final int TRANSACTION_importProfile = (android.os.IBinder.FIRST_CALL_TRANSACTION + 73);
    static final int TRANSACTION_executeQuickAction = (android.os.IBinder.FIRST_CALL_TRANSACTION + 74);
    static final int TRANSACTION_getQuickActionsInfo = (android.os.IBinder.FIRST_CALL_TRANSACTION + 75);
    static final int TRANSACTION_setLockState = (android.os.IBinder.FIRST_CALL_TRANSACTION + 76);
    static final int TRANSACTION_registerForKeyEvents = (android.os.IBinder.FIRST_CALL_TRANSACTION + 77);
    static final int TRANSACTION_getAppInfo = (android.os.IBinder.FIRST_CALL_TRANSACTION + 78);
    static final int TRANSACTION_setMapMargins = (android.os.IBinder.FIRST_CALL_TRANSACTION + 79);
    static final int TRANSACTION_exportProfile = (android.os.IBinder.FIRST_CALL_TRANSACTION + 80);
    static final int TRANSACTION_isFragmentOpen = (android.os.IBinder.FIRST_CALL_TRANSACTION + 81);
    static final int TRANSACTION_isMenuOpen = (android.os.IBinder.FIRST_CALL_TRANSACTION + 82);
    static final int TRANSACTION_getPluginVersion = (android.os.IBinder.FIRST_CALL_TRANSACTION + 83);
    static final int TRANSACTION_selectProfile = (android.os.IBinder.FIRST_CALL_TRANSACTION + 84);
    static final int TRANSACTION_getProfiles = (android.os.IBinder.FIRST_CALL_TRANSACTION + 85);
    static final int TRANSACTION_getBlockedRoads = (android.os.IBinder.FIRST_CALL_TRANSACTION + 86);
    static final int TRANSACTION_addRoadBlock = (android.os.IBinder.FIRST_CALL_TRANSACTION + 87);
    static final int TRANSACTION_removeRoadBlock = (android.os.IBinder.FIRST_CALL_TRANSACTION + 88);
    static final int TRANSACTION_setLocation = (android.os.IBinder.FIRST_CALL_TRANSACTION + 89);
    static final int TRANSACTION_exitApp = (android.os.IBinder.FIRST_CALL_TRANSACTION + 90);
    static final int TRANSACTION_getText = (android.os.IBinder.FIRST_CALL_TRANSACTION + 91);
    static final int TRANSACTION_reloadIndexes = (android.os.IBinder.FIRST_CALL_TRANSACTION + 92);
    static final int TRANSACTION_setPreference = (android.os.IBinder.FIRST_CALL_TRANSACTION + 93);
    static final int TRANSACTION_getPreference = (android.os.IBinder.FIRST_CALL_TRANSACTION + 94);
    static final int TRANSACTION_registerForLogcatMessages = (android.os.IBinder.FIRST_CALL_TRANSACTION + 95);
    static final int TRANSACTION_setZoomLimits = (android.os.IBinder.FIRST_CALL_TRANSACTION + 96);
  }
  public static final java.lang.String DESCRIPTOR = "net.osmand.aidlapi.IOsmAndAidlInterface";
  /**
   * Add map marker at given location.
   * 
   * @param lat (double) -  latitude.
   * @param lon (double) - longitude.
   * @param name (String)- name of marker.
   */
  public boolean addMapMarker(net.osmand.aidlapi.mapmarker.AddMapMarkerParams params) throws android.os.RemoteException;
  /**
   * Remove map marker.
   * 
   * If ignoreCoordinates is false the marker is only removed if lat/lon match the currently set values of the marker.
   * If ignoreCoordinates is true the marker is removed if the name matches, the values of lat/lon are ignored.
   * 
   * @param lat (double) -  latitude.
   * @param lon (double) - longitude.
   * @param name (String)- name of marker.
   * @param ignoreCoordinates (boolean) - flag to determine whether lat/lon shall be ignored
   */
  public boolean removeMapMarker(net.osmand.aidlapi.mapmarker.RemoveMapMarkerParams params) throws android.os.RemoteException;
  /**
   * Update map marker.
   * 
   * If ignoreCoordinates is false the marker gets updated only if latPrev/lonPrev match the currently set values of the marker.
   * If ignoreCoordinates is true the marker gets updated if the name matches, the values of latPrev/lonPrev are ignored.
   * 
   * @param latPrev (double) - latitude (current marker).
   * @param lonPrev (double) - longitude (current marker).
   * @param namePrev (String) - name (current marker).
   * @param latNew (double) - latitude (new marker).
   * @param lonNew (double) - longitude (new marker).
   * @param nameNew (String) - name (new marker).
   * @param ignoreCoordinates (boolean) - flag to determine whether latPrev/lonPrev shall be ignored
   */
  public boolean updateMapMarker(net.osmand.aidlapi.mapmarker.UpdateMapMarkerParams params) throws android.os.RemoteException;
  /**
   * Add map widget to the right side of the main screen.
   * Note: any specified icon should exist in OsmAnd app resources.
   * 
   * @param id (String) - widget id.
   * @param menuIconName (String) - icon name (configure map menu).
   * @param menuTitle (String) - widget name (configure map menu).
   * @param lightIconName (String) - icon name for the light theme (widget).
   * @param darkIconName (String) - icon name for the dark theme (widget).
   * @param text (String) - main widget text.
   * @param description (String) - sub text, like "km/h".
   * @param order (int) - order position in the widgets list.
   * @param intentOnClick (String) - onClick intent. Called after click on widget as startActivity(Intent intent).
   */
  public boolean addMapWidget(net.osmand.aidlapi.mapwidget.AddMapWidgetParams params) throws android.os.RemoteException;
  /**
   * Remove map widget.
   * 
   * @param (String) id - widget id.
   */
  public boolean removeMapWidget(net.osmand.aidlapi.mapwidget.RemoveMapWidgetParams params) throws android.os.RemoteException;
  /**
   * Update map widget.
   * Note: any specified icon should exist in OsmAnd app resources.
   * 
   * @param id (String) - widget id.
   * @param menuIconName (String) - icon name (configure map menu).
   * @param menuTitle (String) - widget name (configure map menu).
   * @param lightIconName (String) - icon name for the light theme (widget).
   * @param darkIconName (String) - icon name for the dark theme (widget).
   * @param text (String) - main widget text.
   * @param description (String) - sub text, like "km/h".
   * @param order (int) - order position in the widgets list.
   * @param intentOnClick (String) - onClick intent. Called after click on widget as startActivity(Intent intent).
   */
  public boolean updateMapWidget(net.osmand.aidlapi.mapwidget.UpdateMapWidgetParams params) throws android.os.RemoteException;
  /**
   * Add point to user layer.
   * 
   * @param layerId (String) - layer id. Note: layer should be added first.
   * @param pointId (String) - point id.
   * @param shortName (String) - short name (single char). Displayed on the map.
   * @param fullName (String) - full name. Displayed in the context menu on first row.
   * @param typeName (String) - type name. Displayed in context menu on second row.
   * @param color (int) - color of circle's background.
   * @param location (ALatLon) - location of the point.
   * @param details (List<String>)- list of details. Displayed under context menu.
   * @param params (Map<String, String>) - optional map of params for point.
   */
  public boolean addMapPoint(net.osmand.aidlapi.maplayer.point.AddMapPointParams params) throws android.os.RemoteException;
  /**
   * Remove point.
   * 
   * @param layerId (String) - layer id.
   * @param pointId (String) - point id.
   */
  public boolean removeMapPoint(net.osmand.aidlapi.maplayer.point.RemoveMapPointParams params) throws android.os.RemoteException;
  /**
   * Update point.
   * 
   * @param layerId (String) - layer id.
   * @param pointId (String) - point id.
   * @param updateOpenedMenuAndMap (boolean) - flag to enable folowing mode and menu updates for point
   * @param shortName (String) - short name (single char). Displayed on the map.
   * @param fullName (String) - full name. Displayed in the context menu on first row.
   * @param typeName (String) - type name. Displayed in context menu on second row.
   * @param color (String) - color of circle's background.
   * @param location (ALatLon)- location of the point.
   * @param details (List<String>) - list of details. Displayed under context menu.
   * @param params (Map<String, String>) - optional map of params for point.
   */
  public boolean updateMapPoint(net.osmand.aidlapi.maplayer.point.UpdateMapPointParams params) throws android.os.RemoteException;
  /**
   * Add user layer on the map.
   * 
   * @param id (String) - layer id.
   * @param name (String) - layer name.
   * @param zOrder (float) - z-order position of layer. Default value is 5.5f
   * @param points Map<Sting, AMapPoint> - initial list of points. Nullable.
   * @param imagePoints (boolean) - use new style for points on map or not. Also default zoom bounds for new style can be edited.
   */
  public boolean addMapLayer(net.osmand.aidlapi.maplayer.AddMapLayerParams params) throws android.os.RemoteException;
  /**
   * Remove user layer.
   * 
   * @param id (String) - layer id.
   */
  public boolean removeMapLayer(net.osmand.aidlapi.maplayer.RemoveMapLayerParams params) throws android.os.RemoteException;
  /**
   * Update user layer.
   * 
   * @param id (String) - layer id.
   * @param name (String) - layer name.
   * @param zOrder (float) - z-order position of layer. Default value is 5.5f
   * @param points Map<Sting, AMapPoint> - list of points. Nullable.
   * @param imagePoints (boolean) - use new style for points on map or not. Also default zoom bounds for new style can be edited.
   */
  public boolean updateMapLayer(net.osmand.aidlapi.maplayer.UpdateMapLayerParams params) throws android.os.RemoteException;
  /**
   * Import GPX file to OsmAnd (from URI or file).
   * 
   * @param gpxUri (Uri) - URI created by FileProvider (preferable method).
   * @param file (File) - File which represents GPX track (not recomended, OsmAnd should have rights to access file location).
   * @param fileName (String) - Destination file name. May contain dirs.
   * @param color (String) - color of gpx. Can be one of: "red", "orange", "lightblue", "blue", "purple",
   *                    "translucent_red", "translucent_orange", "translucent_lightblue",
   *                    "translucent_blue", "translucent_purple"
   * @param show (boolean) - show track on the map after import
   */
  public boolean importGpx(net.osmand.aidlapi.gpx.ImportGpxParams params) throws android.os.RemoteException;
  /**
   * Show GPX file on map.
   * 
   * @param fileName (String) - file name to show. Must be imported first.
   */
  public boolean showGpx(net.osmand.aidlapi.gpx.ShowGpxParams params) throws android.os.RemoteException;
  /**
   * Hide GPX file.
   * 
   * @param fileName (String) - file name to hide.
   */
  public boolean hideGpx(net.osmand.aidlapi.gpx.HideGpxParams params) throws android.os.RemoteException;
  /**
   * Get list of active GPX files.
   * 
   * @return list of active gpx files.
   */
  public boolean getActiveGpx(java.util.List<net.osmand.aidlapi.gpx.ASelectedGpxFile> files) throws android.os.RemoteException;
  /**
   * Set map view to current location.
   * 
   * @param latitude (double) - latitude of new map center.
   * @param longitude (double) - longitude of new map center.
   * @param zoom (float) - map zoom level. Set 0 to keep zoom unchanged.
   * @param animated (boolean) - set true to animate changes.
   */
  public boolean setMapLocation(net.osmand.aidlapi.map.SetMapLocationParams params) throws android.os.RemoteException;
  public boolean calculateRoute(net.osmand.aidlapi.calculateroute.CalculateRouteParams params) throws android.os.RemoteException;
  /** Refresh the map (UI) */
  public boolean refreshMap() throws android.os.RemoteException;
  /**
   * Add favorite group with given params.
   * 
   * @param name (String)    - group name.
   * @param color (String)  - group color. Can be one of: "red", "orange", "yellow",
   *                "lightgreen", "green", "lightblue", "blue", "purple", "pink", "brown".
   * @param visible (boolean) - group visibility.
   */
  public boolean addFavoriteGroup(net.osmand.aidlapi.favorite.group.AddFavoriteGroupParams params) throws android.os.RemoteException;
  /**
   * Remove favorite group with given name.
   * 
   * @param name (String) - name of favorite group.
   */
  public boolean removeFavoriteGroup(net.osmand.aidlapi.favorite.group.RemoveFavoriteGroupParams params) throws android.os.RemoteException;
  /**
   * Update favorite group with given params.
   * 
   * @param namePrev (String) - group name (current).
   * @param colorPrev (String) - group color (current).
   * @param visiblePrev (boolean) - group visibility (current).
   * @param nameNew (String)  - group name (new).
   * @param colorNew (String)  - group color (new).
   * @param visibleNew (boolean) - group visibility (new).
   */
  public boolean updateFavoriteGroup(net.osmand.aidlapi.favorite.group.UpdateFavoriteGroupParams params) throws android.os.RemoteException;
  /**
   * Add favorite at given location with given params.
   * 
   * @param lat (double) - latitude.
   * @param lon (double)  - longitude.
   * @param name (String)  - name of favorite item.
   * @param description (String)  - description of favorite item.
   * @param category (String)  - category of favorite item.
   * @param color (String)  - color of favorite item. Can be one of: "red", "orange", "yellow",
   *                    "lightgreen", "green", "lightblue", "blue", "purple", "pink", "brown".
   * @param visible (boolean) - should favorite item be visible after creation.
   */
  public boolean addFavorite(net.osmand.aidlapi.favorite.AddFavoriteParams params) throws android.os.RemoteException;
  /**
   * Remove favorite at given location with given params.
   * 
   * @param lat (double)  - latitude.
   * @param lon (double) - longitude.
   * @param name (String) - name of favorite item.
   * @param category (String) - category of favorite item.
   */
  public boolean removeFavorite(net.osmand.aidlapi.favorite.RemoveFavoriteParams params) throws android.os.RemoteException;
  /**
   * Update favorite at given location with given params.
   * 
   * @param latPrev (double)  - latitude (current favorite).
   * @param lonPrev (double) - longitude (current favorite).
   * @param namePrev (String) - name of favorite item (current favorite).
   * @param categoryPrev (String) - category of favorite item (current favorite).
   * @param latNew (double)  - latitude (new favorite).
   * @param lonNew (double)  - longitude (new favorite).
   * @param nameNew (String)  - name of favorite item (new favorite).
   * @param descriptionNew (String) - description of favorite item (new favorite).
   * @param categoryNew (String) - category of favorite item (new favorite). Use only to create a new category,
   *                       not to update an existing one. If you want to  update an existing category,
   *                       use the {@link #updateFavoriteGroup(String, String, boolean, String, String, boolean)} method.
   * @param colorNew (String) - color of new category. Can be one of: "red", "orange", "yellow",
   *                       "lightgreen", "green", "lightblue", "blue", "purple", "pink", "brown".
   * @param visibleNew (boolean) - should new category be visible after creation.
   */
  public boolean updateFavorite(net.osmand.aidlapi.favorite.UpdateFavoriteParams params) throws android.os.RemoteException;
  /** Start gpx recording. */
  public boolean startGpxRecording(net.osmand.aidlapi.gpx.StartGpxRecordingParams params) throws android.os.RemoteException;
  /** Stop gpx recording. */
  public boolean stopGpxRecording(net.osmand.aidlapi.gpx.StopGpxRecordingParams params) throws android.os.RemoteException;
  /**
   * Take photo note.
   * 
   * @param lat (double) - latutude of photo note.
   * @param lon (double) - longitude of photo note.
   */
  public boolean takePhotoNote(net.osmand.aidlapi.note.TakePhotoNoteParams params) throws android.os.RemoteException;
  /**
   * Start video note recording.
   * 
   * @param lat (double) - latutude of video note point.
   * @param lon (double) - longitude of video note point.
   */
  public boolean startVideoRecording(net.osmand.aidlapi.note.StartVideoRecordingParams params) throws android.os.RemoteException;
  /**
   * Start audio note recording.
   * 
   * @param lat (double) - latutude of audio note point.
   * @param lon (double) - longitude of audio note point.
   */
  public boolean startAudioRecording(net.osmand.aidlapi.note.StartAudioRecordingParams params) throws android.os.RemoteException;
  /** Stop Audio/Video recording. */
  public boolean stopRecording(net.osmand.aidlapi.note.StopRecordingParams params) throws android.os.RemoteException;
  /**
   * Start navigation.
   * 
   * @param startName (String) - name of the start point as it displays in OsmAnd's UI. Nullable.
   * @param startLat (double) - latitude of the start point. If 0 - current location is used.
   * @param startLon (double) - longitude of the start point. If 0 - current location is used.
   * @param destName (String) - name of the start point as it displays in OsmAnd's UI.
   * @param destLat (double) - latitude of a destination point.
   * @param destLon (double) - longitude of a destination point.
   * @param profile (String)  - One of: "default", "car", "bicycle", "pedestrian", "aircraft", "boat", "hiking", "motorcycle", "truck". Nullable (default).
   * @param force (boolean) - ask to stop current navigation if any. False - ask. True - don't ask.
   */
  public boolean navigate(net.osmand.aidlapi.navigation.NavigateParams params) throws android.os.RemoteException;
  /**
   * Start navigation using gpx file. User need to grant Uri permission to OsmAnd.
   * 
   * @param gpxUri (Uri) - URI created by FileProvider.
   * @param force (boolean) - ask to stop current navigation if any. False - ask. True - don't ask.
   */
  public boolean navigateGpx(net.osmand.aidlapi.navigation.NavigateGpxParams params) throws android.os.RemoteException;
  /**
   * Remove GPX file.
   * 
   * @param fileName (String) - file name to remove;
   */
  public boolean removeGpx(net.osmand.aidlapi.gpx.RemoveGpxParams params) throws android.os.RemoteException;
  /**
   * Show AMapPoint on map in OsmAnd.
   * 
   * @param layerId (String) - layer id. Note: layer should be added first.
   * @param pointId (String) - point id.
   * @param shortName (String) - short name (single char). Displayed on the map.
   * @param fullName (String) - full name. Displayed in the context menu on first row.
   * @param typeName (String) - type name. Displayed in context menu on second row.
   * @param color (int) - color of circle's background.
   * @param location (ALatLon) - location of the point.
   * @param details List<String> - list of details. Displayed under context menu.
   * @param params Map<String, String> - optional map of params for point.
   */
  public boolean showMapPoint(net.osmand.aidlapi.maplayer.point.ShowMapPointParams params) throws android.os.RemoteException;
  /**
   * Method for adding up to 3 items to the OsmAnd navigation drawer.
   * 
   * @param appPackage - current application package.
   * @param names - list of names for items.
   * @param uris - list of uris for intents.
   * @param iconNames - list of icon names for items.
   * @param flags - list of flags for intents. Use -1 if no flags needed.
   */
  public boolean setNavDrawerItems(net.osmand.aidlapi.navdrawer.SetNavDrawerItemsParams params) throws android.os.RemoteException;
  /** Put navigation on pause. */
  public boolean pauseNavigation(net.osmand.aidlapi.navigation.PauseNavigationParams params) throws android.os.RemoteException;
  /** Resume navigation if it was paused before. */
  public boolean resumeNavigation(net.osmand.aidlapi.navigation.ResumeNavigationParams params) throws android.os.RemoteException;
  /** Stop navigation. Removes target / intermediate points and route path from the map. */
  public boolean stopNavigation(net.osmand.aidlapi.navigation.StopNavigationParams params) throws android.os.RemoteException;
  /** Mute voice guidance. Stays muted until unmute manually or via the api. */
  public boolean muteNavigation(net.osmand.aidlapi.navigation.MuteNavigationParams params) throws android.os.RemoteException;
  /** Unmute voice guidance. */
  public boolean unmuteNavigation(net.osmand.aidlapi.navigation.UnmuteNavigationParams params) throws android.os.RemoteException;
  /**
   * Run search for POI / Address.
   * 
   * @param searchQuery (String) - search query string.
   * @param searchType (int) - type of search. Values:
   *                   SearchParams.SEARCH_TYPE_ALL - all kind of search
   *                   SearchParams.SEARCH_TYPE_POI - POIs only
   *                   SearchParams.SEARCH_TYPE_ADDRESS - addresses only
   * 
   * @param latitude (double) - latitude of original search location.
   * @param longitude (double) - longitude of original search location.
   * @param radiusLevel (int) - value from 1 to 7. Default value = 1.
   * @param totalLimit (int) - limit of returned search result rows. Default value = -1 (unlimited).
   */
  public boolean search(net.osmand.aidlapi.search.SearchParams params, net.osmand.aidlapi.IOsmAndAidlCallback callback) throws android.os.RemoteException;
  /**
   * Do search and start navigation.
   * 
   * @param startName (String) - name of the start point as it displays in OsmAnd's UI. Nullable.
   * @param startLat (double) - latitude of the start point. If 0 - current location is used.
   * @param startLon (double) - longitude of the start point. If 0 - current location is used.
   * @param searchQuery (String) - Text of a query for searching a destination point. Sent as URI parameter.
   * @param searchLat (double) - original location of search (latitude). Sent as URI parameter.
   * @param searchLon (double) - original location of search (longitude). Sent as URI parameter.
   * @param profile (String) - one of: "default", "car", "bicycle", "pedestrian", "aircraft", "boat", "hiking", "motorcycle", "truck". Nullable (default).
   * @param force (boolean) - ask to stop current navigation if any. False - ask. True - don't ask.
   */
  public boolean navigateSearch(net.osmand.aidlapi.navigation.NavigateSearchParams params) throws android.os.RemoteException;
  /**
   * Method to register for periodical callbacks from OsmAnd
   * 
   * @param updateTimeMS (long)- period of time in millisecond after which callback is triggered
   * @param callback (IOsmAndCallback)- create and provide instance of {@link IOsmAndAidlCallback} interface
   * @return id (long) - id of callback in OsmAnd. Needed to unsubscribe from updates.
   */
  public long registerForUpdates(long updateTimeMS, net.osmand.aidlapi.IOsmAndAidlCallback callback) throws android.os.RemoteException;
  /**
   * Method to unregister from periodical callbacks from OsmAnd
   * 
   * @param callbackId (long)- id of registered callback (provided by OsmAnd
   * in {@link OsmAndAidlHelper#registerForUpdates(long, IOsmAndAidlCallback)})
   */
  public boolean unregisterFromUpdates(long callbackId) throws android.os.RemoteException;
  /**
   * Method for adding image to the top of Osmand's NavDrawer.
   * 
   * @param imageUri (String)- image's URI.toString
   * 
   * @deprecated
   * Use the {@link #setNavDrawerLogoWithParams(NavDrawerHeaderParams params)} method.
   */
  @Deprecated
  public boolean setNavDrawerLogo(java.lang.String imageUri) throws android.os.RemoteException;
  /**
   * Method for selected UI elements (like QuickSearch button) to show.
   * 
   * @param ids (List<String>)- list of menu items keys from {@link OsmAndCustomizationConstants}
   */
  public boolean setEnabledIds(java.util.List<java.lang.String> ids) throws android.os.RemoteException;
  /**
   * Method for selected UI elements (like QuickSearch button) to hide.
   * 
   * @param ids (List<String>)- list of menu items keys from {@link OsmAndCustomizationConstants}
   */
  public boolean setDisabledIds(java.util.List<java.lang.String> ids) throws android.os.RemoteException;
  /**
   * Method to show selected NavDrawer's menu items.
   * 
   * @param patterns (List<String>) - list of menu items names from {@link OsmAndCustomizationConstants}
   */
  public boolean setEnabledPatterns(java.util.List<java.lang.String> patterns) throws android.os.RemoteException;
  /**
   * Method to hide selected NavDrawer's menu items.
   * 
   * @param patterns (List<String>)- list of menu items names from {@link OsmAndCustomizationConstants}
   */
  public boolean setDisabledPatterns(java.util.List<java.lang.String> patterns) throws android.os.RemoteException;
  /**
   * Register OsmAnd widgets for visibility.
   * 
   * @param widgetKey ()- widget id.
   * @param appModKeys - list of OsmAnd Application modes widget active with. Could be "null" for all modes.
   */
  public boolean regWidgetVisibility(net.osmand.aidlapi.customization.SetWidgetsParams params) throws android.os.RemoteException;
  /**
   * Register OsmAnd widgets for availability.
   * 
   * @param widgetKey (String) - widget id.
   * @param appModKeys (List<String>)- ist of OsmAnd Application modes widget active with. Could be "null" for all modes.
   */
  public boolean regWidgetAvailability(net.osmand.aidlapi.customization.SetWidgetsParams params) throws android.os.RemoteException;
  /**
   * Add custom parameters for OsmAnd settings to associate with client app.
   * 
   * @param sharedPreferencesName (String)- string with name of clint's app for shared preferences key
   * @param bundle (Bundle)- bundle with keys from Settings IDs {@link OsmAndCustomizationConstants} and Settings params
   */
  public boolean customizeOsmandSettings(net.osmand.aidlapi.customization.OsmandSettingsParams params) throws android.os.RemoteException;
  /**
   * Method to get list of gpx files currently registered (imported or created) in OsmAnd;
   * 
   * @return list of gpx files
   */
  public boolean getImportedGpx(java.util.List<net.osmand.aidlapi.gpx.AGpxFile> files) throws android.os.RemoteException;
  /**
   * Method to get list of sqlitedb files registered in OsmAnd;
   * 
   * @return list of sqlitedb files
   */
  public boolean getSqliteDbFiles(java.util.List<net.osmand.aidlapi.tiles.ASqliteDbFile> files) throws android.os.RemoteException;
  /**
   * Method to get list of currently active sqlitedb files
   * 
   * @return list of sqlitedb files
   */
  public boolean getActiveSqliteDbFiles(java.util.List<net.osmand.aidlapi.tiles.ASqliteDbFile> files) throws android.os.RemoteException;
  /**
   * Method to show selected sqlitedb file as map overlay.
   * 
   * @param fileName (String) - name of sqlitedb file
   */
  public boolean showSqliteDbFile(java.lang.String fileName) throws android.os.RemoteException;
  /**
   * Method to hide sqlitedb file from map overlay.
   * 
   * @param fileName (String) - name of sqlitedb file
   */
  public boolean hideSqliteDbFile(java.lang.String fileName) throws android.os.RemoteException;
  /**
   * Method for adding image to the top of OsmAnd's NavDrawer with additional params
   * 
   * @param imageUri (String) - image's URI.toString
   * @param packageName (String) - client's app package name
   * @param intent (String) - intent for additional functionality on image click
   */
  public boolean setNavDrawerLogoWithParams(net.osmand.aidlapi.navdrawer.NavDrawerHeaderParams params) throws android.os.RemoteException;
  /**
   * Method for adding functionality to "Powered by Osmand" logo in NavDrawer's footer
   * (reset OsmAnd settings to pre-clinet app's state)
   * 
   * @param packageName (String) - package name
   * @param intent (String) - intent
   * @param appName (String) - client's app name
   */
  public boolean setNavDrawerFooterWithParams(net.osmand.aidlapi.navdrawer.NavDrawerFooterParams params) throws android.os.RemoteException;
  /**
   * Restore default (pre-client) OsmAnd settings and state:
   * clears features, widgets and settings customization, NavDraw logo.
   */
  public boolean restoreOsmand() throws android.os.RemoteException;
  /**
   * Method to change state of plug-ins in OsmAnd.
   * 
   * @param pluginId (String) - id (name) of plugin.
   * @param newState (int) - new state (0 - off, 1 - on).
   */
  public boolean changePluginState(net.osmand.aidlapi.plugins.PluginParams params) throws android.os.RemoteException;
  /**
   * Method to register for callback on OsmAnd initialization
   * @param callback (IOsmAndAidlCallback) - create and provide instance of {@link IOsmAndAidlCallback} interface
   */
  public boolean registerForOsmandInitListener(net.osmand.aidlapi.IOsmAndAidlCallback callback) throws android.os.RemoteException;
  /**
   * Requests bitmap snap-shot of map with GPX file from provided URI in its center.
   * You can set bitmap size, density and GPX lines color, but you need
   * to manually download appropriate map in OsmAnd or background will be empty.
   * Bitmap will be returned through callback {@link IOsmAndAidlCallback#onGpxBitmapCreated(AGpxBitmap)}
   * 
   * @param gpxUri (Uri/File) - Uri for gpx file
   * @param density (float) - image density. Recommended to use default metrics for device's display.
   * @param widthPixels (int) - width of bitmap
   * @param heightPixels (int) - height of bitmap
   * @param color (int) - color in ARGB format
   * @param callback (IOsmAndAidlCallback) - instance of callback from OsmAnd.
   */
  public boolean getBitmapForGpx(net.osmand.aidlapi.gpx.CreateGpxBitmapParams file, net.osmand.aidlapi.IOsmAndAidlCallback callback) throws android.os.RemoteException;
  /**
   * Method to copy files to OsmAnd part by part. For now supports only sqlitedb format.
   * Part size (bytearray) should not exceed 256k.
   * 
   * @param fileName (String) - name of file
   * @param filePartData (byte[]) - parts of file, byte[] with size 256k or less.
   * @param startTime (long) - timestamp of copying start.
   * @param isDone (boolean) - boolean to mark end of copying.
   * @return number of last successfully received file part or error(-1).
   */
  public int copyFile(net.osmand.aidlapi.copyfile.CopyFileParams filePart) throws android.os.RemoteException;
  /**
   * Method to register for updates during navgation. Notifies user about distance to the next turn and its type.
   * 
   * @param subscribeToUpdates (boolean) - subscribe or unsubscribe from updates
   * @param callbackId (long) - id of callback, needed to unsubscribe from updates
   * @param callback (IOsmAndAidlCallback) - callback to notify user on navigation data change
   */
  public long registerForNavigationUpdates(net.osmand.aidlapi.navigation.ANavigationUpdateParams params, net.osmand.aidlapi.IOsmAndAidlCallback callback) throws android.os.RemoteException;
  /**
   * Method to add Context Menu buttons to OsmAnd Context menu.
   * 
   * {@link ContextMenuButtonsParams } is a wrapper class for params:
   * 
   * @param leftButton (AContextMenuButton) - parameters for left context button:
   * @param buttonId (String at AContextMenuButton) - id of button in View
   * @param leftTextCaption (String at AContextMenuButton) - left-side button text
   * @param rightTextCaption (String at AContextMenuButton) - right-side button text
   * @param String leftIconName (String at AContextMenuButton) - name of left-side icon
   * @param String rightIconName (String at AContextMenuButton) - name of right-side icon
   * @param boolean needColorizeIcon (booleanat AContextMenuButton) - flag to apply color to icon
   * @param boolean enabled (boolean at AContextMenuButton) - enable button flag
   * 
   * @param rightButton (AContextMenuButton) - parameters for right context button, see <i>leftButton</i> param for details.
   * @param id (String) - button id;
   * @param appPackage (String) - clinet's app package name
   * @param layerId (String) - id of Osmand's map layer
   * @param callbackId (long) - {@link IOsmAndAidlCallback} id
   * @param pointsIds (List<String>) - list of point Ids to which this rules applies to.
   * 
   * @param callback (IOsmAndAidlCallback) - AIDL callback;
   * 
   * @return long - callback's Id;
   */
  public long addContextMenuButtons(net.osmand.aidlapi.contextmenu.ContextMenuButtonsParams params, net.osmand.aidlapi.IOsmAndAidlCallback callback) throws android.os.RemoteException;
  /**
   * Method to remove Context Menu buttons from OsmAnd Context menu.
   * 
   * {@link RemoveContextMenuButtonsParams} is a wrapper class for params:
   * 
   * @param paramsId (String) - id of {@link ContextMenuButtonsParams} of button you want to remove;
   * @param callbackId (long) - id of {@ling IOsmAndAidlCallback} of button you want to remove;
   */
  public boolean removeContextMenuButtons(net.osmand.aidlapi.contextmenu.RemoveContextMenuButtonsParams params) throws android.os.RemoteException;
  /**
   * Method to update params on already set custom Context Button.
   * 
   * {@link UpdateContextMenuButtonsParams } is a wrapper class for params:
   * 
   * @param leftButton (AContextMenuButton) - parameters for left context button:
   * @param buttonId (String at AContextMenuButton) - id of button in View
   * @param leftTextCaption (String at AContextMenuButton) - left-side button text
   * @param rightTextCaption (String at AContextMenuButton) - right-side button text
   * @param String leftIconName (String at AContextMenuButton) - name of left-side icon
   * @param String rightIconName (String at AContextMenuButton) - name of right-side icon
   * @param boolean needColorizeIcon (booleanat AContextMenuButton) - flag to apply color to icon
   * @param boolean enabled (boolean at AContextMenuButton) - enable button flag
   * 
   * @param rightButton (AContextMenuButton) - parameters for right context button, see <i>leftButton</i> param for details.
   * @param id (String) - button id;
   * @param appPackage (String) - clinet's app package name
   * @param layerId (String) - id of Osmand's map layer
   * @param callbackId (long) - {@link IOsmAndAidlCallback} id
   * @param pointsIds (List<String>) - list of point Ids to which this rules applies to.
   */
  public boolean updateContextMenuButtons(net.osmand.aidlapi.contextmenu.UpdateContextMenuButtonsParams params) throws android.os.RemoteException;
  /**
   * Method to check if there is a customized setting in OsmAnd Settings.
   * 
   * {@link OsmandSettingsInfoParams} is a wrapper class for params:
   * 
   * @param sharedPreferencesName (String at OsmandSettingInfoParams) - key of setting in OsmAnd's preferences.
   * 
   * @return boolean - true if setting is already set in SharedPreferences
   */
  public boolean areOsmandSettingsCustomized(net.osmand.aidlapi.customization.OsmandSettingsInfoParams params) throws android.os.RemoteException;
  /**
   * Method to customize parameters of OsmAnd.
   * 
   * @param params (CustomizationInfoParams) - wrapper class for custom settings and ui.
   * 
   * @param settingsParams (OsmandSettingsParams) - wrapper class for OsmAnd shared preferences params.
   * 			   See {@link #customizeOsmandSettings(in OsmandSettingsParams params) customizeOsmandSettings}
   * 			   method description for details.
   * @param navDrawerHeaderParams (NavDrawerHeaderParams) - wrapper class for OsmAnd navdrawer header params.
   * 			   See {@link #setNavDrawerLogoWithParams(in NavDrawerHeaderParams params) setNavDrawerLogoWithParams}
   * 			   method description for details.
   * @param navDrawerFooterParams (NavDrawerFooterParams) - wrapper class for OsmAnd navdrawer footer params.
   * 			   See {@link #setNavDrawerFooterWithParams(in NavDrawerFooterParams params) setNavDrawerFooterWithParams}
   * 			   method description for details.
   * @param visibilityWidgetsParams (ArrayList<SetWidgetsParams>) - wrapper class for OsmAnd widgets visibility.
   * 			   See {@link #regWidgetVisibility(in SetWidgetsParams params) regWidgetVisibility}
   * 			   method description for details.
   * @param availabilityWidgetsParams (ArrayList<SetWidgetsParams>) - wrapper class for OsmAnd widgets availability.
   * 			   See {@link #regWidgetAvailability(in SetWidgetsParams params) regWidgetAvailability}
   * 			   method description for details.
   * @param pluginsParams (ArrayList<PluginParams>) - wrapper class for OsmAnd plugins states params.
   * 			   See {@link #changePluginState(in PluginParams params) changePluginState}
   * 			   method description for details.
   * @param featuresEnabledIds (List<String>) - list of UI elements (like QuickSearch button) to show.
   * 			   See {@link #setEnabledIds(in List<String> ids) setEnabledIds}
   * @param featuresDisabledIds (List<String>) - list of UI elements (like QuickSearch button) to hide.
   * 			   See {@link #setDisabledIds(in List<String> ids) setDisabledIds}
   * @param featuresEnabledPatterns (List<String>) - list of NavDrawer menu items to show.
   * 			   See {@link #setEnabledPatterns(in List<String> patterns) setEnabledPatterns}
   * @param featuresDisabledPatterns (List<String>) - list of NavDrawer menu items to hide.
   * 			   See {@link #setDisabledPatterns(in List<String> patterns) setDisabledPatterns}
   */
  public boolean setCustomization(net.osmand.aidlapi.customization.CustomizationInfoParams params) throws android.os.RemoteException;
  /**
   * Method to register for Voice Router voice messages during navigation. Notifies user about voice messages.
   * 
   * @params subscribeToUpdates (boolean) - boolean flag to subscribe or unsubscribe from messages
   * @params callbackId (long) - id of callback, needed to unsubscribe from messages
   * @params callback (IOsmAndAidlCallback) - callback to notify user on voice message
   */
  public long registerForVoiceRouterMessages(net.osmand.aidlapi.navigation.ANavigationVoiceRouterMessageParams params, net.osmand.aidlapi.IOsmAndAidlCallback callback) throws android.os.RemoteException;
  /**
   * Removes all active map markers (marks them as passed and moves to history)
   * Empty class of params
   */
  public boolean removeAllActiveMapMarkers(net.osmand.aidlapi.mapmarker.RemoveMapMarkersParams params) throws android.os.RemoteException;
  public boolean importProfile(net.osmand.aidlapi.customization.ProfileSettingsParams params) throws android.os.RemoteException;
  public boolean executeQuickAction(net.osmand.aidlapi.quickaction.QuickActionParams params) throws android.os.RemoteException;
  public boolean getQuickActionsInfo(java.util.List<net.osmand.aidlapi.quickaction.QuickActionInfoParams> quickActions) throws android.os.RemoteException;
  /** Toggle Lock/Unlock screen. */
  public boolean setLockState(net.osmand.aidlapi.lock.SetLockStateParams params) throws android.os.RemoteException;
  /**
   * Method to register for  key events.
   * 
   * @params subscribeToUpdates (boolean) - boolean flag to subscribe or unsubscribe from key events
   * @params callbackId (long) - id of callback, needed to unsubscribe key events
   * @params callback (IOsmAndAidlCallback) - callback to notify user on key event
   * @params keyEventList (List<Integer>) - list of requested key events
   */
  public long registerForKeyEvents(net.osmand.aidlapi.events.AKeyEventsParams params, net.osmand.aidlapi.IOsmAndAidlCallback callback) throws android.os.RemoteException;
  public net.osmand.aidlapi.info.AppInfoParams getAppInfo() throws android.os.RemoteException;
  public boolean setMapMargins(net.osmand.aidlapi.customization.MapMarginsParams params) throws android.os.RemoteException;
  public boolean exportProfile(net.osmand.aidlapi.profile.ExportProfileParams params) throws android.os.RemoteException;
  /** Is any fragment open. */
  public boolean isFragmentOpen() throws android.os.RemoteException;
  /** Is contect menu open. */
  public boolean isMenuOpen() throws android.os.RemoteException;
  public int getPluginVersion(net.osmand.aidlapi.customization.CustomPluginParams params) throws android.os.RemoteException;
  public boolean selectProfile(net.osmand.aidlapi.customization.SelectProfileParams params) throws android.os.RemoteException;
  public boolean getProfiles(java.util.List<net.osmand.aidlapi.customization.AProfile> profiles) throws android.os.RemoteException;
  public boolean getBlockedRoads(java.util.List<net.osmand.aidlapi.navigation.ABlockedRoad> blockedRoads) throws android.os.RemoteException;
  public boolean addRoadBlock(net.osmand.aidlapi.navigation.AddBlockedRoadParams params) throws android.os.RemoteException;
  public boolean removeRoadBlock(net.osmand.aidlapi.navigation.RemoveBlockedRoadParams params) throws android.os.RemoteException;
  public boolean setLocation(net.osmand.aidlapi.map.SetLocationParams params) throws android.os.RemoteException;
  public boolean exitApp(net.osmand.aidlapi.exit.ExitAppParams params) throws android.os.RemoteException;
  public boolean getText(net.osmand.aidlapi.info.GetTextParams params) throws android.os.RemoteException;
  public boolean reloadIndexes() throws android.os.RemoteException;
  public boolean setPreference(net.osmand.aidlapi.customization.PreferenceParams params) throws android.os.RemoteException;
  public boolean getPreference(net.osmand.aidlapi.customization.PreferenceParams params) throws android.os.RemoteException;
  /**
   * Method to register for Logcat messages. Notifies user about new logs in application.
   * 
   * @param subscribeToUpdates (boolean) - boolean flag to subscribe or unsubscribe from messages
   * @param callbackId (long) - id of callback, needed to unsubscribe from messages
   * @param filterLevel (String) determines which type of logs will be returned by callback
   * Must be one of the values below:
   * - "D" (debug)
   * - "I" (info)
   * - "W" (warn)
   * - "E" (error)
   * @param callback (IOsmAndAidlCallback) - callback to notify user on new OsmAnd logs
   */
  public long registerForLogcatMessages(net.osmand.aidlapi.logcat.ALogcatListenerParams params, net.osmand.aidlapi.IOsmAndAidlCallback callback) throws android.os.RemoteException;
  public boolean setZoomLimits(net.osmand.aidlapi.customization.ZoomLimitsParams params) throws android.os.RemoteException;
  /** @hide */
  static class _Parcel {
    static private <T> T readTypedObject(
        android.os.Parcel parcel,
        android.os.Parcelable.Creator<T> c) {
      if (parcel.readInt() != 0) {
          return c.createFromParcel(parcel);
      } else {
          return null;
      }
    }
    static private <T extends android.os.Parcelable> void writeTypedObject(
        android.os.Parcel parcel, T value, int parcelableFlags) {
      if (value != null) {
        parcel.writeInt(1);
        value.writeToParcel(parcel, parcelableFlags);
      } else {
        parcel.writeInt(0);
      }
    }
    static private <T extends android.os.Parcelable> void writeTypedList(
        android.os.Parcel parcel, java.util.List<T> value, int parcelableFlags) {
      if (value == null) {
        parcel.writeInt(-1);
      } else {
        int N = value.size();
        int i = 0;
        parcel.writeInt(N);
        while (i < N) {
    writeTypedObject(parcel, value.get(i), parcelableFlags);
          i++;
        }
      }
    }
  }
}
