/**
 * Automatically generated file. DO NOT MODIFY
 */
package net.osmand.aidlapi;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "net.osmand.aidlapi";
  public static final String BUILD_TYPE = "release";
}
